package net.countered.datagen;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2444;
import net.minecraft.class_7800;
import java.util.function.Consumer;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> consumer) {
        method_32804(class_7800.field_40634, ModBlocksRegistry.DIRT_SLAB, class_1856.method_8091(class_2246.field_10566)).method_33530("has_dirt_block", method_10426(class_2246.field_10566)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.MUD_SLAB, class_1856.method_8091(class_2246.field_37576)).method_33530("has_mud_block", method_10426(class_2246.field_37576)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.COARSE_SLAB, class_1856.method_8091(class_2246.field_10253)).method_33530("has_coarse_dirt_block", method_10426(class_2246.field_10253)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.SNOW_SLAB, class_1856.method_8091(class_2246.field_10491)).method_33530("has_snow_block", method_10426(class_2246.field_10491)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.PACKED_ICE_SLAB, class_1856.method_8091(class_2246.field_10225)).method_33530("has_packed_ice_block", method_10426(class_2246.field_10225)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.DEEPSLATE_SLAB, class_1856.method_8091(class_2246.field_28888)).method_33530("has_deepslate_block", method_10426(class_2246.field_28888)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.CLAY_SLAB, class_1856.method_8091(class_2246.field_10460)).method_33530("has_clay_block", method_10426(class_2246.field_10460)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.MOSS_SLAB, class_1856.method_8091(class_2246.field_28681)).method_33530("has_moss_block", method_10426(class_2246.field_28681)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.CUSTOM_TUFF_SLAB, class_1856.method_8091(class_2246.field_27165)).method_33530("has_tuff_block", method_10426(class_2246.field_27165)).method_10431(consumer);

        //terralith
        method_32804(class_7800.field_40634, ModBlocksRegistry.CALCITE_SLAB, class_1856.method_8091(class_2246.field_27114)).method_33530("has_calcite", method_10426(class_2246.field_27114)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.SMOOTH_BASALT_SLAB, class_1856.method_8091(class_2246.field_29032)).method_33530("has_smooth_basalt", method_10426(class_2246.field_29032)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10325)).method_33530("has_light_blue_terracotta", method_10426(class_2246.field_10325)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.CYAN_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10235)).method_33530("has_cyan_terracotta", method_10426(class_2246.field_10235)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.ICE_SLAB, class_1856.method_8091(class_2246.field_10295)).method_33530("has_ice", method_10426(class_2246.field_10295)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.ROOTED_DIRT_SLAB, class_1856.method_8091(class_2246.field_28685)).method_33530("has_rooted_dirt", method_10426(class_2246.field_28685)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.PACKED_MUD_SLAB, class_1856.method_8091(class_2246.field_37556)).method_33530("has_packed_mud", method_10426(class_2246.field_37556)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.BLUE_ICE_SLAB, class_1856.method_8091(class_2246.field_10384)).method_33530("has_blue_ice", method_10426(class_2246.field_10384)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.BLACK_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10626)).method_33530("has_black_terracotta", method_10426(class_2246.field_10626)).method_10431(consumer);

        method_32804(class_7800.field_40634, ModBlocksRegistry.GRASS_SLAB, class_1856.method_8091(class_2246.field_10219)).method_33530("has_grass_block", method_10426(class_2246.field_10219)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.MYCELIUM_SLAB, class_1856.method_8091(class_2246.field_10402)).method_33530("has_mycelium_block", method_10426(class_2246.field_10402)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.PODZOL_SLAB, class_1856.method_8091(class_2246.field_10520)).method_33530("has_podzol_block", method_10426(class_2246.field_10520)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.PATH_SLAB, class_1856.method_8091(class_2246.field_10194)).method_33530("has_dirt_path_block", method_10426(class_2246.field_10194)).method_10431(consumer);

        method_32804(class_7800.field_40634, ModBlocksRegistry.GRAVEL_SLAB, class_1856.method_8091(class_2246.field_10255)).method_33530("has_gravel_block", method_10426(class_2246.field_10255)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.SAND_SLAB, class_1856.method_8091(class_2246.field_10102)).method_33530("has_sand_block", method_10426(class_2246.field_10102)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.RED_SAND_SLAB, class_1856.method_8091(class_2246.field_10534)).method_33530("has_red_sand_block", method_10426(class_2246.field_10534)).method_10431(consumer);

        method_32804(class_7800.field_40634, ModBlocksRegistry.TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10415)).method_33530("has_terracotta_block", method_10426(class_2246.field_10415)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.RED_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10328)).method_33530("has_red_terracotta_block", method_10426(class_2246.field_10328)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10184)).method_33530("has_orange_terracotta_block", method_10426(class_2246.field_10184)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10590)).method_33530("has_light_gray_terracotta_block", method_10426(class_2246.field_10590)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.WHITE_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10611)).method_33530("has_white_terracotta_block", method_10426(class_2246.field_10611)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.BROWN_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10123)).method_33530("has_brown_terracotta_block", method_10426(class_2246.field_10123)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB, class_1856.method_8091(class_2246.field_10143)).method_33530("has_yellow_terracotta_block", method_10426(class_2246.field_10143)).method_10431(consumer);

        method_32804(class_7800.field_40634, ModBlocksRegistry.SOUL_SAND_SLAB, class_1856.method_8091(class_2246.field_10114)).method_33530("has_soul_sand_block", method_10426(class_2246.field_10114)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.SOUL_SOIL_SLAB, class_1856.method_8091(class_2246.field_22090)).method_33530("has_soul_soil_block", method_10426(class_2246.field_22090)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.NETHERRACK_SLAB, class_1856.method_8091(class_2246.field_10515)).method_33530("has_netherrack_block", method_10426(class_2246.field_10515)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.WARPED_NYLIUM_SLAB, class_1856.method_8091(class_2246.field_22113)).method_33530("has_warped_nylium_block", method_10426(class_2246.field_22113)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.CRIMSON_NYLIUM_SLAB, class_1856.method_8091(class_2246.field_22120)).method_33530("has_crimson_nylium_block", method_10426(class_2246.field_22120)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.BASALT_SLAB, class_1856.method_8091(class_2246.field_22091)).method_33530("has_basalt_block", method_10426(class_2246.field_22091)).method_10431(consumer);
        method_32804(class_7800.field_40634, ModBlocksRegistry.ENDSTONE_SLAB, class_1856.method_8091(class_2246.field_10471)).method_33530("has_end_stone_block", method_10426(class_2246.field_10471)).method_10431(consumer);

    }
}
