package net.countered.datagen;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;


public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 generator) {
        Map<class_2248, class_2248> slabMap = new HashMap<>();
        slabMap.put(class_2246.field_10340, ModBlocksRegistry.CUSTOM_STONE_SLAB);
        slabMap.put(class_2246.field_27165, ModBlocksRegistry.CUSTOM_TUFF_SLAB);
        slabMap.put(class_2246.field_10115, ModBlocksRegistry.CUSTOM_ANDESITE_SLAB);
        slabMap.put(class_2246.field_10508, ModBlocksRegistry.CUSTOM_DIORITE_SLAB);
        slabMap.put(class_2246.field_10474, ModBlocksRegistry.CUSTOM_GRANITE_SLAB);

        slabMap.put(class_2246.field_10255, ModBlocksRegistry.GRAVEL_SLAB);
        slabMap.put(class_2246.field_10102, ModBlocksRegistry.SAND_SLAB);
        slabMap.put(class_2246.field_10534, ModBlocksRegistry.RED_SAND_SLAB);

        slabMap.put(class_2246.field_10566, ModBlocksRegistry.DIRT_SLAB);
        slabMap.put(class_2246.field_37576, ModBlocksRegistry.MUD_SLAB);
        slabMap.put(class_2246.field_10253, ModBlocksRegistry.COARSE_SLAB);
        slabMap.put(class_2246.field_10225, ModBlocksRegistry.PACKED_ICE_SLAB);
        slabMap.put(class_2246.field_10460, ModBlocksRegistry.CLAY_SLAB);
        slabMap.put(class_2246.field_28888, ModBlocksRegistry.DEEPSLATE_SLAB);
        slabMap.put(class_2246.field_28681, ModBlocksRegistry.MOSS_SLAB);
        // terralith
        slabMap.put(class_2246.field_27114, ModBlocksRegistry.CALCITE_SLAB);
        slabMap.put(class_2246.field_29032, ModBlocksRegistry.SMOOTH_BASALT_SLAB);
        slabMap.put(class_2246.field_10325, ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10235, ModBlocksRegistry.CYAN_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10445, ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB);
        slabMap.put(class_2246.field_9989, ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB);
        slabMap.put(class_2246.field_29031, ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB);
        slabMap.put(class_2246.field_10295, ModBlocksRegistry.ICE_SLAB);
        slabMap.put(class_2246.field_28685, ModBlocksRegistry.ROOTED_DIRT_SLAB);
        slabMap.put(class_2246.field_37556, ModBlocksRegistry.PACKED_MUD_SLAB);
        slabMap.put(class_2246.field_10384, ModBlocksRegistry.BLUE_ICE_SLAB);
        slabMap.put(class_2246.field_10626, ModBlocksRegistry.BLACK_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10135, ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB);

        slabMap.put(class_2246.field_10415, ModBlocksRegistry.TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10328, ModBlocksRegistry.RED_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10184, ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10590, ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10611, ModBlocksRegistry.WHITE_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10123, ModBlocksRegistry.BROWN_TERRACOTTA_SLAB);
        slabMap.put(class_2246.field_10143, ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB);

        slabMap.put(class_2246.field_10114, ModBlocksRegistry.SOUL_SAND_SLAB);
        slabMap.put(class_2246.field_22090, ModBlocksRegistry.SOUL_SOIL_SLAB);
        slabMap.put(class_2246.field_10515, ModBlocksRegistry.NETHERRACK_SLAB);
        slabMap.put(class_2246.field_23869, ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB);
        slabMap.put(class_2246.field_10471, ModBlocksRegistry.ENDSTONE_SLAB);

        for (Map.Entry<class_2248, class_2248> entry : slabMap.entrySet()) {
            generateCubeAllSlab(entry.getKey(), entry.getValue(), generator);
        }
    }

    private void generateCubeAllSlab(class_2248 base, class_2248 slab, class_4910 generator) {
        class_2960 baseId = class_7923.field_41175.method_10221(base);
        class_2960 baseTextureId = new class_2960(baseId.method_12836(), "block/" + baseId.method_12832());

        class_4944 textures = class_4944.method_25875(baseTextureId);

        class_2960 slabModel = class_4943.field_22909.method_25846(slab, textures, generator.field_22831);
        class_2960 slabTopModel = class_4943.field_22910.method_25846(slab, textures, generator.field_22831);

        class_2960 doubleModel = class_4943.field_22972.method_25853(slab, "_double", textures, generator.field_22831);

        generator.field_22830.accept(class_4910.method_25668(
                slab, slabModel, slabTopModel, doubleModel
        ));
        generator.method_25623(slab, slabModel);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}
