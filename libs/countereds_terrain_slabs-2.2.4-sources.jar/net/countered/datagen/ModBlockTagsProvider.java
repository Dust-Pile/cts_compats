package net.countered.datagen;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagsProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagsProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        this.method_10512(class_3481.field_15469)
                .add(ModBlocksRegistry.DIRT_SLAB)
                .add(ModBlocksRegistry.MUD_SLAB)
                .add(ModBlocksRegistry.COARSE_SLAB)
                .add(ModBlocksRegistry.SNOW_SLAB)
                .add(ModBlocksRegistry.PACKED_ICE_SLAB)
                .add(ModBlocksRegistry.DEEPSLATE_SLAB)
                .add(ModBlocksRegistry.CLAY_SLAB)
                .add(ModBlocksRegistry.MOSS_SLAB)

                //terralith compat
                .add(ModBlocksRegistry.CALCITE_SLAB)
                .add(ModBlocksRegistry.SMOOTH_BASALT_SLAB)
                .add(ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CYAN_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB)
                .add(ModBlocksRegistry.ICE_SLAB)
                .add(ModBlocksRegistry.ROOTED_DIRT_SLAB)
                .add(ModBlocksRegistry.PACKED_MUD_SLAB)
                .add(ModBlocksRegistry.BLUE_ICE_SLAB)
                .add(ModBlocksRegistry.BLACK_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB)

                .add(ModBlocksRegistry.GRASS_SLAB)
                .add(ModBlocksRegistry.MYCELIUM_SLAB)
                .add(ModBlocksRegistry.PODZOL_SLAB)
                .add(ModBlocksRegistry.PATH_SLAB)

                .add(ModBlocksRegistry.GRAVEL_SLAB)
                .add(ModBlocksRegistry.SAND_SLAB)
                .add(ModBlocksRegistry.RED_SAND_SLAB)

                .add(ModBlocksRegistry.TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.RED_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.WHITE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.BROWN_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB)

                .add(ModBlocksRegistry.CUSTOM_TUFF_SLAB)
                .add(ModBlocksRegistry.CUSTOM_STONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_DIORITE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_ANDESITE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_GRANITE_SLAB)

                .add(ModBlocksRegistry.SOUL_SAND_SLAB)
                .add(ModBlocksRegistry.SOUL_SOIL_SLAB)
                .add(ModBlocksRegistry.NETHERRACK_SLAB)
                .add(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB)
                .add(ModBlocksRegistry.WARPED_NYLIUM_SLAB)
                .add(ModBlocksRegistry.BASALT_SLAB)
                .add(ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB)
                .add(ModBlocksRegistry.ENDSTONE_SLAB);

        this.method_10512(class_3481.field_33716)
                .add(ModBlocksRegistry.DIRT_SLAB)
                .add(ModBlocksRegistry.MUD_SLAB)
                .add(ModBlocksRegistry.COARSE_SLAB)
                .add(ModBlocksRegistry.SNOW_SLAB)
                .add(ModBlocksRegistry.CLAY_SLAB)
                .add(ModBlocksRegistry.GRASS_SLAB)
                .add(ModBlocksRegistry.MYCELIUM_SLAB)
                .add(ModBlocksRegistry.PODZOL_SLAB)
                .add(ModBlocksRegistry.PATH_SLAB)
                .add(ModBlocksRegistry.GRAVEL_SLAB)
                .add(ModBlocksRegistry.SAND_SLAB)
                .add(ModBlocksRegistry.RED_SAND_SLAB)
                .add(ModBlocksRegistry.SNOW_ON_TOP)

                .add(ModBlocksRegistry.SOUL_SAND_SLAB)
                .add(ModBlocksRegistry.SOUL_SOIL_SLAB)

                //terralith
                .add(ModBlocksRegistry.ROOTED_DIRT_SLAB);

        this.method_10512(class_3481.field_33715)
                .add(ModBlocksRegistry.PACKED_ICE_SLAB)
                .add(ModBlocksRegistry.DEEPSLATE_SLAB)
                .add(ModBlocksRegistry.TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.RED_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.WHITE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.BROWN_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CUSTOM_TUFF_SLAB)
                .add(ModBlocksRegistry.CUSTOM_GRANITE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_ANDESITE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_DIORITE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_STONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB)
                //terralith
                .add(ModBlocksRegistry.CALCITE_SLAB)
                .add(ModBlocksRegistry.SMOOTH_BASALT_SLAB)
                .add(ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CYAN_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB)
                .add(ModBlocksRegistry.ICE_SLAB)
                .add(ModBlocksRegistry.PACKED_MUD_SLAB)
                .add(ModBlocksRegistry.BLUE_ICE_SLAB)
                .add(ModBlocksRegistry.BLACK_TERRACOTTA_SLAB)
                .add(ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB)

                .add(ModBlocksRegistry.NETHERRACK_SLAB)
                .add(ModBlocksRegistry.WARPED_NYLIUM_SLAB)
                .add(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB)
                .add(ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB)
                .add(ModBlocksRegistry.BASALT_SLAB)
                .add(ModBlocksRegistry.ENDSTONE_SLAB);

        this.method_10512(class_3481.field_33714)
                .add(ModBlocksRegistry.MOSS_SLAB);

        this.method_10512(class_3481.field_33713)
                .add(ModBlocksRegistry.DEAD_BUSH_ON_TOP)
                .add(ModBlocksRegistry.SHORT_GRASS_ON_TOP)
                .add(ModBlocksRegistry.FERN_ON_TOP)
                .add(ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP)
                .add(ModBlocksRegistry.RED_MUSHROOM_ON_TOP);

        this.method_10512(class_3481.field_44469)
                .add(ModBlocksRegistry.DEAD_BUSH_ON_TOP)
                .add(ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP)
                .add(ModBlocksRegistry.RED_MUSHROOM_ON_TOP)
                .add(ModBlocksRegistry.SHORT_GRASS_ON_TOP)
                .add(ModBlocksRegistry.FERN_ON_TOP);


        this.method_10512(class_3481.field_42968).add(ModBlocksRegistry.SAND_SLAB, ModBlocksRegistry.RED_SAND_SLAB);

        this.method_10512(class_3481.field_35571).add(ModBlocksRegistry.GRASS_SLAB);

        this.method_10512(class_3481.field_35567).add(ModBlocksRegistry.GRASS_SLAB);

        this.method_10512(class_3481.field_15478).add(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.PODZOL_SLAB);

        this.method_10512(class_3481.field_35568).add(ModBlocksRegistry.CLAY_SLAB);

        this.method_10512(class_3481.field_35573).add(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.SNOW_SLAB, ModBlocksRegistry.SAND_SLAB);

        this.method_10512(class_3481.field_35569) //needs improvement
                .add(ModBlocksRegistry.CUSTOM_STONE_SLAB, ModBlocksRegistry.SNOW_SLAB, ModBlocksRegistry.PACKED_ICE_SLAB, ModBlocksRegistry.GRAVEL_SLAB);

        this.method_10512(class_3481.field_29823).add(ModBlocksRegistry.SNOW_SLAB).add(ModBlocksRegistry.SNOW_ON_TOP);

        this.method_10512(class_3481.field_37399)
                .add(ModBlocksRegistry.CUSTOM_STONE_SLAB)
                .add(ModBlocksRegistry.DIRT_SLAB)
                .add(ModBlocksRegistry.TERRACOTTA_SLAB)  //need extension
                .add(ModBlocksRegistry.SAND_SLAB, ModBlocksRegistry.RED_SAND_SLAB)
                .add(ModBlocksRegistry.GRAVEL_SLAB)
                .add(ModBlocksRegistry.CLAY_SLAB)
                .add(ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB)
                .add(ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB);


        this.method_10512(class_3481.field_36268)
                .add(ModBlocksRegistry.CUSTOM_STONE_SLAB)
                .add(ModBlocksRegistry.DIRT_SLAB)
                .add(ModBlocksRegistry.TERRACOTTA_SLAB)  //need extension
                .add(ModBlocksRegistry.RED_SAND_SLAB)
                .add(ModBlocksRegistry.CLAY_SLAB)
                .add(ModBlocksRegistry.GRAVEL_SLAB)
                .add(ModBlocksRegistry.SAND_SLAB)
                .add(ModBlocksRegistry.SNOW_SLAB);

        this.method_10512(class_3481.field_42607)
                .add(ModBlocksRegistry.DIRT_SLAB, ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.PODZOL_SLAB, ModBlocksRegistry.COARSE_SLAB, ModBlocksRegistry.MOSS_SLAB, ModBlocksRegistry.MUD_SLAB);

        this.method_10512(class_3481.field_35575).add(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.SNOW_SLAB, ModBlocksRegistry.COARSE_SLAB, ModBlocksRegistry.PODZOL_SLAB);

        this.method_10512(class_3481.field_35574).add(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.SNOW_SLAB, ModBlocksRegistry.PODZOL_SLAB, ModBlocksRegistry.COARSE_SLAB);

        this.method_10512(class_3481.field_38692)
                .add(ModBlocksRegistry.MUD_SLAB);

        this.method_10512(class_3481.field_38693)
                .add(ModBlocksRegistry.MUD_SLAB);

        this.method_10512(class_3481.field_38928).add(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.MUD_SLAB);

        this.method_10512(class_3481.field_15496).add(ModBlocksRegistry.SEAGRASS_ON_TOP);

        this.method_10512(class_3481.field_23063).add(ModBlocksRegistry.SOUL_SAND_SLAB, ModBlocksRegistry.SOUL_SOIL_SLAB);

        this.method_10512(class_3481.field_25588).add(ModBlocksRegistry.NETHERRACK_SLAB);

        this.method_10512(class_3481.field_25739).add(ModBlocksRegistry.MYCELIUM_SLAB).add(ModBlocksRegistry.PODZOL_SLAB).add(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB).add(ModBlocksRegistry.WARPED_NYLIUM_SLAB);

        this.method_10512(class_3481.field_17753).add(ModBlocksRegistry.ENDSTONE_SLAB);

        this.method_10512(class_3481.field_21953).add(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB, ModBlocksRegistry.WARPED_NYLIUM_SLAB);

    }
}
