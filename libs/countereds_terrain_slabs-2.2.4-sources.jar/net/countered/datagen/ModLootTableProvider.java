package net.countered.datagen;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_182;
import net.minecraft.class_1893;
import net.minecraft.class_212;
import net.minecraft.class_215;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2771;
import net.minecraft.class_44;
import net.minecraft.class_4559;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_65;
import net.minecraft.class_77;
import net.minecraft.class_79;
import net.minecraft.class_85;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {
        this.method_45994(ModBlocksRegistry.DIRT_SLAB, block -> silkSlabDrops(block, class_2246.field_10566));
        this.method_45994(ModBlocksRegistry.MUD_SLAB, block -> silkSlabDrops(block, class_2246.field_37576));
        this.method_45994(ModBlocksRegistry.COARSE_SLAB, block -> silkSlabDrops(block, class_2246.field_10253));
        this.method_45994(ModBlocksRegistry.DEEPSLATE_SLAB, block -> silkSlabDrops(block, class_2246.field_29031));
        this.method_45994(ModBlocksRegistry.MOSS_SLAB, block -> silkSlabDrops(block, class_2246.field_28681));
        //terralith
        this.method_45994(ModBlocksRegistry.CALCITE_SLAB, block -> silkSlabDrops(block, class_2246.field_27114));
        this.method_45994(ModBlocksRegistry.SMOOTH_BASALT_SLAB, block -> silkSlabDrops(block, class_2246.field_29032));
        this.method_45994(ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10325));
        this.method_45994(ModBlocksRegistry.CYAN_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10235));
        this.method_45994(ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_10445));
        this.method_45994(ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_9989));
        this.method_45994(ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB, block -> silkSlabDrops(block, class_2246.field_29031));
        this.method_45994(ModBlocksRegistry.ICE_SLAB, block -> silkSlabDrops(block, class_2246.field_10295));
        this.method_45994(ModBlocksRegistry.ROOTED_DIRT_SLAB, block -> silkSlabDrops(block, class_2246.field_28685));
        this.method_45994(ModBlocksRegistry.PACKED_MUD_SLAB, block -> silkSlabDrops(block, class_2246.field_37556));
        this.method_45994(ModBlocksRegistry.BLUE_ICE_SLAB, block -> silkSlabDrops(block, class_2246.field_10384));
        this.method_45994(ModBlocksRegistry.BLACK_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10626));
        this.method_45994(ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB, block -> silkSlabDrops(block, class_2246.field_10135));
        this.method_45994(ModBlocksRegistry.SAND_SLAB, block -> silkSlabDrops(block, class_2246.field_10102));
        this.method_45994(ModBlocksRegistry.RED_SAND_SLAB, block -> silkSlabDrops(block, class_2246.field_10534));

        this.method_45994(ModBlocksRegistry.TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10415));
        this.method_45994(ModBlocksRegistry.RED_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10328));
        this.method_45994(ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10184));
        this.method_45994(ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10590));
        this.method_45994(ModBlocksRegistry.WHITE_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10611));
        this.method_45994(ModBlocksRegistry.BROWN_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10123));
        this.method_45994(ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB, block -> silkSlabDrops(block, class_2246.field_10143));

        this.method_45994(ModBlocksRegistry.CUSTOM_STONE_SLAB, block -> silkSlabDrops(block, class_2246.field_10445));
        this.method_45994(ModBlocksRegistry.CUSTOM_ANDESITE_SLAB, block -> silkSlabDrops(block, class_2246.field_10115));
        this.method_45994(ModBlocksRegistry.CUSTOM_DIORITE_SLAB, block -> silkSlabDrops(block, class_2246.field_10508));
        this.method_45994(ModBlocksRegistry.CUSTOM_GRANITE_SLAB, block -> silkSlabDrops(block, class_2246.field_10474));
        this.method_45994(ModBlocksRegistry.CUSTOM_TUFF_SLAB, block -> silkSlabDrops(block, class_2246.field_27165));
        this.method_45994(ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_9979));
        this.method_45994(ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_10344));

        this.method_45994(ModBlocksRegistry.MYCELIUM_SLAB, block -> silkSlabDrops(block, class_2246.field_10566));
        this.method_45994(ModBlocksRegistry.PODZOL_SLAB, block -> silkSlabDrops(block, class_2246.field_10566));
        this.method_45994(ModBlocksRegistry.GRASS_SLAB, block -> silkSlabDrops(block, class_2246.field_10566));
        this.method_45994(ModBlocksRegistry.PATH_SLAB, block -> silkSlabDrops(block, class_2246.field_10566));

        this.method_45994(ModBlocksRegistry.SOUL_SAND_SLAB, block -> silkSlabDrops(block, class_2246.field_10114));
        this.method_45994(ModBlocksRegistry.SOUL_SOIL_SLAB, block -> silkSlabDrops(block, class_2246.field_22090));
        this.method_45994(ModBlocksRegistry.NETHERRACK_SLAB, block -> silkSlabDrops(block, class_2246.field_10515));
        this.method_45994(ModBlocksRegistry.WARPED_NYLIUM_SLAB, block -> silkSlabDrops(block, class_2246.field_10515));
        this.method_45994(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB, block -> silkSlabDrops(block, class_2246.field_10515));
        this.method_45994(ModBlocksRegistry.BASALT_SLAB, block -> silkSlabDrops(block, class_2246.field_22091));
        this.method_45994(ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_23869));
        this.method_45994(ModBlocksRegistry.ENDSTONE_SLAB, block -> silkSlabDrops(block, class_2246.field_10471));

        this.method_45994(ModBlocksRegistry.PACKED_ICE_SLAB, this::onlySilkSlabDrops);

        this.method_45994(ModBlocksRegistry.SNOW_SLAB, block -> silkSlabDropsParts(block, class_1802.field_8543));
        this.method_45994(ModBlocksRegistry.CLAY_SLAB, block -> silkSlabDropsParts(block, class_1802.field_8696));
        this.method_45994(ModBlocksRegistry.SNOW_ON_TOP, (block) -> {
            return class_52.method_324().method_336(class_55.method_347().method_356(class_215.method_15972(class_47.class_50.field_935)).method_351(class_65.method_386(new class_79.class_80[]{class_65.method_43734(class_2488.field_11518.method_11898(), (integer) -> {
                return ((class_85.class_86) class_77.method_411(class_1802.field_8543).method_421(class_212.method_900(block).method_22584(class_4559.class_4560.method_22523().method_22524(class_2488.field_11518, integer)))).method_438(class_141.method_621(class_44.method_32448((float)integer)));
            }).method_421(field_40603), class_65.method_43734(class_2488.field_11518.method_11898(), (integer) -> {
                return (class_79.class_80)(integer == 8 ? class_77.method_411(class_2246.field_10491) : class_77.method_411(class_2246.field_10477).method_438(class_141.method_621(class_44.method_32448((float)integer))).method_421(class_212.method_900(block).method_22584(class_4559.class_4560.method_22523().method_22524(class_2488.field_11518, integer))));
            })})));
        });
        this.method_45994(
                ModBlocksRegistry.GRAVEL_SLAB,
                block -> gravelSlabDrops(block, class_2246.field_10255, class_1802.field_8145)
        );

        this.method_45994(ModBlocksRegistry.POPPY_ON_TOP, block -> this.method_45983(block, class_2246.field_10449));
        this.method_45994(ModBlocksRegistry.DANDELION_ON_TOP, block -> this.method_45983(block, class_2246.field_10182));
        this.method_45994(ModBlocksRegistry.AZURE_BLUET_ON_TOP, block -> this.method_45983(block, class_2246.field_10573));
        this.method_45994(ModBlocksRegistry.CORNFLOWER_ON_TOP, block -> this.method_45983(block, class_2246.field_9995));
        this.method_45994(ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP, block -> this.method_45983(block, class_2246.field_10251));
        this.method_45994(ModBlocksRegistry.RED_MUSHROOM_ON_TOP, block -> this.method_45983(block, class_2246.field_10559));
        this.method_45994(ModBlocksRegistry.FERN_ON_TOP, block -> this.method_46017(class_2246.field_10112));
        this.method_45994(ModBlocksRegistry.SHORT_GRASS_ON_TOP, block -> this.method_46017(class_2246.field_10479));
        this.method_45994(
                ModBlocksRegistry.DEAD_BUSH_ON_TOP,
                block -> this.method_46001(
                        class_2246.field_10428,
                        (class_79.class_80<?>)this.method_45977(
                                block, class_77.method_411(class_1802.field_8600).method_438(class_141.method_621(class_5662.method_32462(0.0F, 2.0F)))
                        )
                )
        );
        this.method_45994(ModBlocksRegistry.SEAGRASS_ON_TOP, block -> this.method_45995(class_2246.field_10376));

    }

    /**
     * Adds a loot table entry that makes the slab drop its base block instead of itself.
     */
    public class_52.class_53 gravelSlabDrops(class_2248 slab, class_2248 gravelDrop, class_1792 flintDrop) {
        return class_52.method_324()
                .method_336(
                        class_55.method_347()
                                .method_352(class_44.method_32448(1.0F))
                                .method_351(
                                        class_77.method_411(slab)
                                                .method_421(field_40602)
                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                        .method_524(class_212.method_900(slab)
                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                        )
                                                )
                                                .method_417(
                                                        class_77.method_411(flintDrop)
                                                                .method_421(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true))
                                                                )
                                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                        .method_524(class_212.method_900(slab)
                                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                        )
                                                                )
                                                                .method_421(class_182.method_800(
                                                                        class_1893.field_9130,
                                                                        0.1F, 0.14285715F, 0.25F, 1.0F
                                                                ))
                                                )
                                                .method_417(
                                                        class_77.method_411(gravelDrop)
                                                                .method_421(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true))
                                                                )
                                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                        .method_524(class_212.method_900(slab)
                                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                        )
                                                                )
                                                )
                                                .method_417(
                                                        class_77.method_411(slab)
                                                                .method_421(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, false))
                                                                )
                                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                        .method_524(class_212.method_900(slab)
                                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                        )
                                                                )
                                                )
                                )
                );
    }

    public class_52.class_53 silkSlabDrops(class_2248 slab, class_2248 drop) {
        return class_52.method_324()
                .method_336(
                        class_55.method_347()
                                .method_352(class_44.method_32448(1.0F))
                                .method_351(
                                        class_77.method_411(slab)
                                                .method_421(field_40602)  // Silk Touch condition
                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                        .method_524(class_212.method_900(slab)
                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                        )
                                                )
                                                .method_417(
                                                        class_77.method_411(drop)
                                                                .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true)))
                                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                        .method_524(class_212.method_900(slab)
                                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                        )
                                                                )
                                                )
                                                .method_417(
                                                        class_77.method_411(slab)
                                                                .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, false)))
                                                                .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                        .method_524(class_212.method_900(slab)
                                                                                .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                        )
                                                                )
                                                )
                                )
                );
    }

    public class_52.class_53 silkSlabDropsParts(class_2248 slab, class_1792 drop) {
        return class_52.method_324()
                .method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_351(
                                class_77.method_411(slab)
                                        .method_421(field_40602)  // Silk Touch condition
                                        .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                .method_524(class_212.method_900(slab)
                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                )
                                        )
                                        .method_417(
                                                class_77.method_411(drop)
                                                        .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true)))
                                                        .method_438(class_141.method_621(class_44.method_32448(8.0F))
                                                                .method_524(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                )
                                                        )
                                                        .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true)))
                                                        .method_438(class_141.method_621(class_44.method_32448(4.0F))
                                                                .method_524(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12681))
                                                                )
                                                        )
                                                        .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, true)))
                                                        .method_438(class_141.method_621(class_44.method_32448(4.0F))
                                                                .method_524(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12679))
                                                                )
                                                        )
                                        )
                                        .method_417(
                                                class_77.method_411(slab)
                                                        .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, false)))
                                                        .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                .method_524(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                )
                                                        )
                                        )
                        )
                );
    }

    public class_52.class_53 onlySilkSlabDrops(class_2248 slab) {
        return class_52.method_324()
                .method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_351(
                                class_77.method_411(slab)
                                        .method_421(field_40602)  // Silk Touch condition
                                        .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                .method_524(class_212.method_900(slab)
                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                )
                                        )
                                        .method_417(
                                                class_77.method_411(slab)
                                                        .method_421(class_212.method_900(slab).method_22584(class_4559.class_4560.method_22523().method_22527(CustomSlab.GENERATED, false)))
                                                        .method_438(class_141.method_621(class_44.method_32448(2.0F))
                                                                .method_524(class_212.method_900(slab)
                                                                        .method_22584(class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682))
                                                                )
                                                        )
                                        )

                        )
                );
    }
}
