package net.countered.terrainslabs;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1163;
import net.minecraft.class_1921;
import net.minecraft.class_1933;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class TerrainSlabsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModContainer mod = FabricLoader.getInstance().getModContainer(TerrainSlabs.MOD_ID).orElseThrow();
        ResourceManagerHelper.registerBuiltinResourcePack(
                new class_2960(TerrainSlabs.MOD_ID, "better_grass_slabs"),
                mod,
                ResourcePackActivationType.NORMAL
        );
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.ICE_SLAB, class_1921.method_23583());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.GRASS_SLAB, class_1921.method_23579());

        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.POPPY_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.DANDELION_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.AZURE_BLUET_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.CORNFLOWER_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.SHORT_GRASS_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.FERN_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.RED_MUSHROOM_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.DEAD_BUSH_ON_TOP, class_1921.method_23579());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocksRegistry.SEAGRASS_ON_TOP, class_1921.method_23579());

        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
                return world != null && pos != null
                        ? class_1163.method_4962(world, pos)
                        : class_1933.method_49724();
        }, ModBlocksRegistry.GRASS_SLAB);


        ColorProviderRegistry.ITEM.register(
                (stack, tintIndex) ->
                        class_310.method_1551().method_1505().method_1697(class_2246.field_10219.method_9564(), null, null, tintIndex),
                ModBlocksRegistry.GRASS_SLAB
        );

        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
                return world != null && pos != null
                        ? class_1163.method_4962(world, pos)
                        : class_1933.method_49724();
        }, ModBlocksRegistry.SHORT_GRASS_ON_TOP);


        ColorProviderRegistry.ITEM.register(
                (stack, tintIndex) ->
                        class_310.method_1551().method_1505().method_1697(class_2246.field_10479.method_9564(), null, null, tintIndex),
                ModBlocksRegistry.SHORT_GRASS_ON_TOP
        );

        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
                return world != null && pos != null
                        ? class_1163.method_4962(world, pos)
                        : class_1933.method_49724();
        }, ModBlocksRegistry.FERN_ON_TOP);

        ColorProviderRegistry.ITEM.register(
                (stack, tintIndex) ->
                        class_310.method_1551().method_1505().method_1697(class_2246.field_10112.method_9564(), null, null, tintIndex),
                ModBlocksRegistry.FERN_ON_TOP
        );
    }
}
