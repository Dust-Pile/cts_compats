package net.countered.terrainslabs.worldgen.slabfeature;

import net.countered.terrainslabs.worldgen.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class ModSlabGeneration {
    public static void generateSlabs(){
        BiomeModifications.addFeature(BiomeSelectors.all(),
                class_2893.class_2895.field_13172, ModPlacedFeatures.SLAB_FEATURE_PLACED_KEY);
    }
}
