package net.countered.terrainslabs.worldgen.feature;

import net.countered.terrainslabs.TerrainSlabs;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import java.util.List;

public class ModPlacedFeatures {

    public static final class_5321<class_6796> SLAB_FEATURE_PLACED_KEY = registerKey("slab_feature_placed");

    public static void bootstrap(class_7891<class_6796> context){
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);

        register(context, SLAB_FEATURE_PLACED_KEY,
                configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.SLAB_FEATURE_KEY),
                List.of(
                        class_6793.method_39623(1),
                        class_6792.method_39614()// Once per chunk
                )
        );
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_43902(TerrainSlabs.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }
}
