package net.countered.terrainslabs.worldgen.feature;

import net.countered.terrainslabs.TerrainSlabs;
import net.countered.terrainslabs.worldgen.slabfeature.SlabFeatureLogic;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_7923;

public class ModAddedFeatures {
    // Register your custom SlabFeature
    public static final class_3031<class_3111> SLAB_FEATURE = new SlabFeatureLogic(class_3111.field_24893);

    public static void registerFeatures() {
        // Register the slab feature in the feature registry
        class_2378.method_10230(class_7923.field_41144, class_2960.method_43902(TerrainSlabs.MOD_ID, "slab_feature"), SLAB_FEATURE);
    }
}
