package net.countered.terrainslabs.worldgen.feature;

import net.countered.terrainslabs.TerrainSlabs;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;

public class ModConfiguredFeatures {

    public static final class_5321<class_2975<?,?>> SLAB_FEATURE_KEY = registerKey("slab_feature");


    public static void bootstrap(class_7891<class_2975<?,?>> context){
        register(context, SLAB_FEATURE_KEY, ModAddedFeatures.SLAB_FEATURE, class_3037.field_13603);    }


    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_43902(TerrainSlabs.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}
