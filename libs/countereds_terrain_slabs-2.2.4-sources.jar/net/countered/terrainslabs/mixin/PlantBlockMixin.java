package net.countered.terrainslabs.mixin;

import net.countered.terrainslabs.mixinProxy.PlantBlockProxy;
import net.minecraft.class_1922;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin( class_2261.class )
public abstract class PlantBlockMixin implements PlantBlockProxy {

    @Shadow
    protected abstract boolean canPlantOnTop(class_2680 floor, class_1922 world, class_2338 pos);

    @Unique
    public boolean terrain_slabs_mod$canPlantOnTopProxy(class_2680 state, class_1922 world, class_2338 pos ) {
        return this.canPlantOnTop( state, world, pos );
    }

}
