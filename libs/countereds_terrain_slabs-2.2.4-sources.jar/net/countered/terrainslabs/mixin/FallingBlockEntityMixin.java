package net.countered.terrainslabs.mixin;

import net.countered.terrainslabs.block.ModSlabsMap;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.countered.terrainslabs.block.interfaces.IBlockCopy;
import net.minecraft.class_1540;
import net.minecraft.class_1542;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin( class_1540.class )
public abstract class FallingBlockEntityMixin {

    @Redirect( method = "tick", at = @At( value = "INVOKE",
            target = "Lnet/minecraft/entity/FallingBlockEntity;dropItem(Lnet/minecraft/item/ItemConvertible;)Lnet/minecraft/entity/ItemEntity;" )
    )
    private class_1542 dropItemProxy(class_1540 instance, class_1935 itemConvertible) {
        if ( instance.method_6962().method_26204() instanceof IBlockCopy ) {
            return instance.method_5870( class_2246.field_10124, 1 );
        }

        class_2248 slab = ModSlabsMap.SLAB_MAP.getOrDefault( instance.method_6962().method_26204(), class_2246.field_10124 );
        if ( slab.equals( class_2246.field_10124 ) ) {
            return instance.method_5706( itemConvertible );
        }

        class_1937 world = instance.method_37908();
        class_2338 belowPos = instance.method_24515();
        class_2680 belowState = world.method_8320( belowPos );
        class_2680 currentStateAtPos = world.method_8320( belowPos.method_10084() );
        if ( !( belowState.method_27852( slab ) && belowState.method_11654( CustomSlab.GENERATED ) )
                || !( currentStateAtPos.method_26164( class_3481.field_44471 ) || currentStateAtPos.method_26215()
                        || currentStateAtPos.method_27852( class_2246.field_10382 ) )
        ) {
            return instance.method_5706( itemConvertible );
        }

        class_2680 state = instance.method_6962();
        world.method_8501( belowPos, state.method_26204().method_34725( belowState ) );
        world.method_8501( instance.method_24515().method_10084(), state );
        return instance.method_5870( class_2246.field_10124, 1 );
    }
}
