package net.countered.terrainslabs.mixin;

import net.countered.terrainslabs.block.ModSlabsMap;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.countered.terrainslabs.block.interfaces.IBlockCopy;
import net.minecraft.class_1540;
import net.minecraft.class_1542;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin( class_1540.class )
public abstract class FallingBlockEntityMixin {

    /**
     * This method allows the correct item to be dropped by IBlockCopy falling slabs, as well as includes
     * special behaviour for blocks falling on a generated copy of themselves (places on top if possible
     * and converts the slab to a block)
     * @param instance falling block entity which is being removed
     * @param itemConvertible object that will convert to the item dropped by default
     * @return Item entity that will be spawned
     */
    @Redirect( method = "tick", at = @At( value = "INVOKE",
            target = "Lnet/minecraft/entity/FallingBlockEntity;dropItem(Lnet/minecraft/item/ItemConvertible;)Lnet/minecraft/entity/ItemEntity;" )
    )
    private class_1542 dropItemProxy( class_1540 instance, class_1935 itemConvertible) {
        // block copies have their own listener to handle this.
        class_2680 fallingBlockState = instance.method_6962();
        if ( fallingBlockState.method_26204() instanceof IBlockCopy ) {
            return instance.method_5870( class_2246.field_10124, 1 );
        }

        class_2248 slab = ModSlabsMap.SLAB_MAP.getOrDefault( fallingBlockState.method_26204(), class_2246.field_10124 );
        if ( slab.equals( class_2246.field_10124 ) ) {
            return instance.method_5706( itemConvertible );
        }

        class_1937 world = instance.method_37908();
        class_2338 belowPos = instance.method_24515();

        // If block types match and slab is generated, place on top instead of breaking for better natural behaviour
        class_2680 belowState = world.method_8320( belowPos );
        if ( !terrainSlabs$canPlaceOn( world, belowPos, slab ) ) {
            return instance.method_5706( itemConvertible );
        }

        class_2248 belowBlock = ModSlabsMap.BLOCK_BELOW_REPLACEMENT_MAP.getOrDefault( slab, fallingBlockState.method_26204() );
        world.method_8501( belowPos, belowBlock.method_34725( belowState ) );
        world.method_8501( instance.method_24515().method_10084(), fallingBlockState );
        return instance.method_5870( class_2246.field_10124, 1 );
    }

    @Unique
    private static boolean terrainSlabs$canPlaceOn(class_1937 world, class_2338 belowPos, class_2248 slab ) {
        class_2680 currentStateAtPos = world.method_8320( belowPos.method_10084() );
        if ( !( currentStateAtPos.method_26164( class_3481.field_44471 ) || currentStateAtPos.method_26215()
                || currentStateAtPos.method_27852( class_2246.field_10382 ) )
        ) {
            return false;
        }

        class_2680 belowState = world.method_8320( belowPos );
        if ( !belowState.method_28501().contains( CustomSlab.GENERATED ) || !belowState.method_11654( CustomSlab.GENERATED ) ) {
            return false;
        }

        return belowState.method_27852( slab ) || belowState.method_27852( ModSlabsMap.TOP_SLAB_REPLACEMENT_MAP.getOrDefault( slab,
                ModSlabsMap.INVERSE_SLAB_REPLACEMENT_MAP.getOrDefault( slab, class_2246.field_10124 ) )
        );
    }

}
