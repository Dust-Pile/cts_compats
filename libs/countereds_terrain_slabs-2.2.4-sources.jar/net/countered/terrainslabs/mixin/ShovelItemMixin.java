package net.countered.terrainslabs.mixin;

import net.fabricmc.fabric.mixin.content.registry.ShovelItemAccessor;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1821;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5712;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static net.minecraft.class_2482.field_11501;
import static net.minecraft.class_2482.field_11502;

@Mixin(class_1821.class)
public abstract class ShovelItemMixin {

    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void useOnCustomSlab(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        class_1937 world = context.method_8045();
        class_2338 blockPos = context.method_8037();
        class_2680 blockState = world.method_8320(blockPos);

        if (context.method_8038() == class_2350.field_11033) {
            return;
        }

        class_2680 pathState = ShovelItemAccessor.getPathStates().get(blockState.method_26204());

        // Check if it's a slab block registered for path conversion
        if (pathState != null && blockState.method_26204() instanceof class_2482 && world.method_8320(blockPos.method_10084()).method_26215()) {
            class_1657 playerEntity = context.method_8036();
            class_2771 slabType = blockState.method_11654(field_11501);
            pathState = pathState.method_11657(field_11501, slabType).method_11657(field_11502, blockState.method_11654(field_11502));

            world.method_8396(playerEntity, blockPos, class_3417.field_14616, class_3419.field_15245, 1.0F, 1.0F);
            if (!world.field_9236) {
                world.method_8652(blockPos, pathState, 11);
                world.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(playerEntity, pathState));
                if (playerEntity != null) {
                    context.method_8041().method_7956(1, playerEntity, (p) -> {
                        p.method_20236(context.method_20287());
                    });
                }
            }

            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
