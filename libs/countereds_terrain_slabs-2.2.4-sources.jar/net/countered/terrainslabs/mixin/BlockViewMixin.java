package net.countered.terrainslabs.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin( class_1922.class )
public interface BlockViewMixin {

    /**
     * Injects into lambda responsible for the "blockHitFactory" in the core raytrace method of BlockView.
     * Adds on a check for whether the block above the raytrace target is seen in front of the actual voxel targeted.
     * This check allows "onTop" slab blocks to be targeted correctly.
     * @param innerContext RaycastContext
     * @param pos BlockPos
     * @param cir CallbackInfoReturnable
     * @param blockHitResult BlockHitResult
     * @param blockHitResult2 BlockHitResult for fluid
     */
    @Inject( method = "method_17743", at = @At( "RETURN" ), cancellable = true)
    private void onBlockHitFactory(
            class_3959 innerContext,
            class_2338 pos,
            CallbackInfoReturnable<class_3965> cir,
            @Local( ordinal = 0 ) class_3965 blockHitResult,
            @Local( ordinal = 1 ) class_3965 blockHitResult2
    ) {
        class_2338 abovePos = new class_2338( pos.method_10263(), pos.method_10264() + 1, pos.method_10260() );
        class_2680 blockStateAbove = this.getBlockState( abovePos );
        class_265 voxelShape3 = innerContext.method_17748( blockStateAbove, (class_1922) this, abovePos );
        class_3965 blockHitResultAbove = this.raycastBlock( innerContext.method_17750(), innerContext.method_17747(), abovePos, voxelShape3, blockStateAbove );
        double f = blockHitResultAbove == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResultAbove.method_17784());

        double d = blockHitResult == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult.method_17784());
        double e = blockHitResult2 == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult2.method_17784());

        if ( f <= d && f <= e ) {
            cir.setReturnValue(blockHitResultAbove);
        }
    }

    @Shadow
    class_2680 getBlockState(class_2338 pos);

    @Shadow
    default class_3965 raycastBlock(class_243 start, class_243 end, class_2338 pos, class_265 shape, class_2680 state) {
        return null;
    }

}
