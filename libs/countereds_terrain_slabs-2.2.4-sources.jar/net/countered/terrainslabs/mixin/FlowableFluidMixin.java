package net.countered.terrainslabs.mixin;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2771;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin( class_3609.class )
public abstract class FlowableFluidMixin {

    @Unique
    private static final class_2746 GENERATED = class_2746.method_11825("generated");

    @Redirect( method = "flow", at = @At( value = "INVOKE",
            target = "Lnet/minecraft/block/FluidFillable;tryFillWithFluid(Lnet/minecraft/world/WorldAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/fluid/FluidState;)Z"))
    private boolean tryFillWithFluidProxy(
            class_2402 instance, class_1936 world,
            class_2338 pos, class_2680 state, class_3610 fluidState
    ) {
        if ( state.method_28501().contains( GENERATED ) && state.method_11654( GENERATED ) ) {
            world.method_22352( pos, true );
            world.method_8652( pos, fluidState.method_15759(), class_2248.field_31036 );
            return true;
        }
        return instance.method_10311( world, pos, state, fluidState );
    }

    @Inject( method = "canFill", at = @At( "HEAD" ), cancellable = true )
    private void onCanFill(
            class_1922 world, class_2338 pos,
            class_2680 state, class_3611 fluid,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if ( state.method_26204() instanceof class_2482 && state.method_28501().contains( GENERATED )
                && state.method_11654( GENERATED ) && state.method_11654( class_2741.field_12485 ).equals( class_2771.field_12681 )
                && state.method_11654( class_2741.field_12508 ).equals( false )
        ) {
            cir.setReturnValue( true );
            cir.cancel();
        }
    }

}
