package net.countered.terrainslabs.mixin;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2771;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin( class_3609.class )
public abstract class FlowableFluidMixin {

    @Unique
    private static final class_2746 GENERATED = class_2746.method_11825("generated");

    /**
     * Fluid considers trying to flow into generated slabs
     */
    @Inject( method = "canFill", at = @At( "HEAD" ), cancellable = true )
    private void onCanFill(
            class_1922 world, class_2338 pos,
            class_2680 state, class_3611 fluid,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if ( state.method_26204() instanceof class_2482 && state.method_28501().contains( GENERATED )
                && state.method_11654( GENERATED ) && state.method_11654( class_2741.field_12485 ).equals( class_2771.field_12681 )
                && state.method_11654( class_2741.field_12508 ).equals( false )
        ) {
            cir.setReturnValue( true );
            cir.cancel();
        }
    }

    /**
     * Fluid flows into generated slabs if the fluid level is high enough
     * @param world world
     * @param pos pos
     * @param state blockState flowing into
     * @param direction flow direction
     * @param fluidState fluidState
     * @param ci context
     */
    @Inject( method = "flow", at = @At( "HEAD" ), cancellable = true )
    void onFlow(
            class_1936 world, class_2338 pos,
            class_2680 state, class_2350 direction,
            class_3610 fluidState, CallbackInfo ci
    ) {
        if ( !state.method_28501().contains( GENERATED ) || !state.method_11654( GENERATED ) ) {
            return;
        }
        if ( direction == class_2350.field_11033 || fluidState.method_15761() >= 4 ) {
            world.method_22352( pos, false );
            world.method_8652( pos, fluidState.method_15759(), class_2248.field_31036 );
            ci.cancel();
        }
    }
}
