package net.countered.terrainslabs.item;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.fabric.mixin.content.registry.ShovelItemAccessor;
import net.minecraft.class_2248;

public class ShovelPathSlab {

    public static void init() {
        // Register each slab type with the default path slab state.
        registerSlabPath(ModBlocksRegistry.DIRT_SLAB);
        registerSlabPath(ModBlocksRegistry.GRASS_SLAB);
        registerSlabPath(ModBlocksRegistry.MYCELIUM_SLAB);
        registerSlabPath(ModBlocksRegistry.PODZOL_SLAB);
    }

    private static void registerSlabPath(class_2248 originalSlab) {
        // Register the slab with its default path slab block state in PATH_STATES.
        ShovelItemAccessor.getPathStates().put(originalSlab, ModBlocksRegistry.PATH_SLAB.method_9564());
    }
}



