package net.countered.terrainslabs.item;

import net.countered.terrainslabs.TerrainSlabs;
import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {

    public static final class_1761 TERRAIN_SLABS = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_43902(TerrainSlabs.MOD_ID, "terrainslabs"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.terrainslabs"))
            .method_47320(() -> new class_1799(ModBlocksRegistry.GRASS_SLAB)).method_47317((displayContext, entries) -> {

                entries.method_45421(ModBlocksRegistry.DIRT_SLAB);
                entries.method_45421(ModBlocksRegistry.MUD_SLAB);
                entries.method_45421(ModBlocksRegistry.COARSE_SLAB);
                entries.method_45421(ModBlocksRegistry.SNOW_SLAB);
                entries.method_45421(ModBlocksRegistry.PACKED_ICE_SLAB);
                entries.method_45421(ModBlocksRegistry.DEEPSLATE_SLAB);
                entries.method_45421(ModBlocksRegistry.CLAY_SLAB);
                entries.method_45421(ModBlocksRegistry.MOSS_SLAB);
                //terralith
                entries.method_45421(ModBlocksRegistry.CALCITE_SLAB);
                entries.method_45421(ModBlocksRegistry.SMOOTH_BASALT_SLAB);
                entries.method_45421(ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.CYAN_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB);
                entries.method_45421(ModBlocksRegistry.ICE_SLAB);
                entries.method_45421(ModBlocksRegistry.ROOTED_DIRT_SLAB);
                entries.method_45421(ModBlocksRegistry.PACKED_MUD_SLAB);
                entries.method_45421(ModBlocksRegistry.BLUE_ICE_SLAB);
                entries.method_45421(ModBlocksRegistry.BLACK_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB);

                entries.method_45421(ModBlocksRegistry.GRASS_SLAB);
                entries.method_45421(ModBlocksRegistry.MYCELIUM_SLAB);
                entries.method_45421(ModBlocksRegistry.PODZOL_SLAB);
                entries.method_45421(ModBlocksRegistry.PATH_SLAB);

                entries.method_45421(ModBlocksRegistry.GRAVEL_SLAB);
                entries.method_45421(ModBlocksRegistry.SAND_SLAB);
                entries.method_45421(ModBlocksRegistry.RED_SAND_SLAB);

                entries.method_45421(ModBlocksRegistry.TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.RED_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.WHITE_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.BROWN_TERRACOTTA_SLAB);
                entries.method_45421(ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB);

                entries.method_45421(ModBlocksRegistry.CUSTOM_ANDESITE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_DIORITE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_GRANITE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_STONE_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_TUFF_SLAB);

                entries.method_45421(ModBlocksRegistry.SOUL_SAND_SLAB);
                entries.method_45421(ModBlocksRegistry.SOUL_SOIL_SLAB);
                entries.method_45421(ModBlocksRegistry.NETHERRACK_SLAB);
                entries.method_45421(ModBlocksRegistry.WARPED_NYLIUM_SLAB);
                entries.method_45421(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB);
                entries.method_45421(ModBlocksRegistry.BASALT_SLAB);
                entries.method_45421(ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB);
                entries.method_45421(ModBlocksRegistry.ENDSTONE_SLAB);
            }).method_47324());

    public static void registerItemGroups() {
        TerrainSlabs.LOGGER.info("Registering Mod Item Groups");
    }
}