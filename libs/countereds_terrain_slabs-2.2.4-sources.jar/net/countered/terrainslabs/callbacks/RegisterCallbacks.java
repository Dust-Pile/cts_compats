package net.countered.terrainslabs.callbacks;

import net.countered.terrainslabs.block.ModBlockTags;
import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.countered.terrainslabs.block.ModSlabsMap;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.countered.terrainslabs.block.interfaces.BlockCopyWrapper;
import net.countered.terrainslabs.block.interfaces.IBlockCopy;
import net.countered.terrainslabs.mixinProxy.PlantBlockProxy;
import net.countered.terrainslabs.config.MyModConfig;
import net.countered.terrainslabs.persistence.SlabChunkAttachment;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2756;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import java.util.*;

public class RegisterCallbacks {
    private static final Map<class_1792, class_2248> VEGETATION_ON_TOP_ITEMS = new HashMap<>();

    static {
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8880, ModBlocksRegistry.POPPY_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8491, ModBlocksRegistry.DANDELION_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_17501, ModBlocksRegistry.AZURE_BLUET_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_17513, ModBlocksRegistry.CORNFLOWER_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8602, ModBlocksRegistry.SHORT_GRASS_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8471, ModBlocksRegistry.FERN_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8689, ModBlocksRegistry.DEAD_BUSH_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_17516, ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_17517, ModBlocksRegistry.RED_MUSHROOM_ON_TOP);
        VEGETATION_ON_TOP_ITEMS.put(class_1802.field_8158, ModBlocksRegistry.SEAGRASS_ON_TOP);
    }

    @SuppressWarnings("unused")
    public static void putVegetationOnTopItemFromString(String keyMod, String keyName, String valueMod, String valueName ) {
        class_1792 item = class_7923.field_41178.method_10223( class_2960.method_43902( keyMod, keyName ) );
        class_2248 onTopBlock = class_7923.field_41175.method_10223( class_2960.method_43902( valueMod, valueName ) );
        VEGETATION_ON_TOP_ITEMS.put( item, onTopBlock );
    }

    public static void registerCallbacks() {
        registerPlaceOnTopCallback();
        registerSlabPlacementCallback();
    }

    private static void registerPlaceOnTopCallback(){
        UseBlockCallback.EVENT.register((class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) -> {
            class_1799 item = player.method_5998(hand);

            // TODO: Allow plants to be placed on a double slab as normal?
            class_2338 blockPos = hitResult.method_17777().method_10093(hitResult.method_17780());
            class_2680 blockBelowState = world.method_8320(blockPos.method_10074());
            if ( !( blockBelowState.method_26204() instanceof class_2482
                    && blockBelowState.method_11654(class_2741.field_12485).equals(class_2771.field_12681) ) )
            {
                return class_1269.field_5811;
            }

            class_2680 currentBlockState = world.method_8320(blockPos);
            boolean blockPosIsAir = currentBlockState.method_26215() || currentBlockState.method_26164( class_3481.field_44471 );
            if (item.method_7909() == class_1802.field_8749) {
                // Ensure the block can be replaced and there's air at the target position
                if ((blockPosIsAir || currentBlockState.method_26204() == ModBlocksRegistry.SNOW_ON_TOP)) {
                    // Replace with custom snow slab
                    int currentLayers = world.method_8320(blockPos).method_26204() instanceof class_2488
                            ? world.method_8320(blockPos).method_11654(class_2488.field_11518)
                            : 0;

                    // If snow layers can be increased, increase by 1 layer
                    if (currentLayers < class_2488.field_31247) {
                        world.method_8501(blockPos, ModBlocksRegistry.SNOW_ON_TOP.method_9564()
                                .method_11657(class_2488.field_11518, currentLayers + 1));

                        // Play placement sound and consume one snow slab
                        world.method_8396(player, blockPos, class_3417.field_14945, class_3419.field_15245, 1.0F, 1.0F);
                        if (!player.method_7337()) {
                            item.method_7934(1);
                        }
                        return class_1269.field_5812;
                    }
                }
                return class_1269.field_5811;
            }

            if ( !VEGETATION_ON_TOP_ITEMS.containsKey(item.method_7909()) ) {
                return class_1269.field_5811; // Cancel if is not on top vegetation
            }

            class_2680 vegetationState = VEGETATION_ON_TOP_ITEMS.get(item.method_7909()).method_9564();
            boolean canBeWaterlogged = vegetationState.method_28501().contains( class_2741.field_12508 );
            boolean blockPosIsWater = currentBlockState.method_27852(class_2246.field_10382);
            if ( lacksValidFluidStateAndReplacement( vegetationState, canBeWaterlogged, blockPosIsWater, blockPosIsAir )
                    || !canPlaceOnTop( vegetationState, blockBelowState, world, blockPos ) )
            {
                return class_1269.field_5811; // Cancel if original vegetation is not compatible with original block
            }

            Collection<class_2769<?>> properties = vegetationState.method_28501();
            if ( properties.contains( class_2741.field_12481 ) ) {
                vegetationState = vegetationState.method_11657( class_2741.field_12481, player.method_5735().method_10153() );
            }

            if ( vegetationState.method_26204() instanceof class_2320 ) {
                class_2338 topPos = blockPos.method_10084();
                class_2680 topState = world.method_8320( topPos );
                boolean topBlockIsWater = topState.method_26204().equals( class_2246.field_10382 );
                if ( lacksValidFluidStateAndReplacement( topState, canBeWaterlogged, topBlockIsWater, topState.method_26215() ) ) {
                    return class_1269.field_5811;
                }
            }

            world.method_8652(blockPos, withWaterloggedState( vegetationState, canBeWaterlogged, blockPosIsWater ), class_2248.field_31027);
            world.method_8396(player, blockPos, vegetationState.method_26231().method_10598(), class_3419.field_15245, 1.0F, 1.0F);
            if ( vegetationState.method_26204() instanceof class_2320 ) {
                ( vegetationState.method_26204()).method_9567( world, blockPos, vegetationState, player, item );
            }

            if (!player.method_7337()) {
                item.method_7934(1);
            }
            return class_1269.field_5812;

        });
    }

    static boolean canPlaceOnTop( class_2680 vegetationState, class_2680 blockBelowState, class_1937 world, class_2338 pos ) {
        if ( vegetationState.method_26204() instanceof IBlockCopy copy && copy.hasPlacementRule( "custom" ) ) {
            return vegetationState.method_26184( world, pos );
        }

        if ( vegetationState.method_26204() instanceof class_2261 ) {
            if ( !( blockBelowState.method_26204() instanceof IBlockCopy ) ) {
                return false;
            }

            class_2248 originPlant = new BlockCopyWrapper( (IBlockCopy) vegetationState.method_26204() ).getOriginBlock();
            class_2248 originBlock = new BlockCopyWrapper( (IBlockCopy) blockBelowState.method_26204() ).getOriginBlock();
            return ((PlantBlockProxy) originPlant).terrain_slabs_mod$canPlantOnTopProxy(
                    originBlock.method_34725(blockBelowState), world, pos);
        }
        return true;
    }

    @SuppressWarnings("UnstableApiUsage")
    private static void registerSlabPlacementCallback() {
        ServerChunkEvents.CHUNK_LOAD.register((serverWorld, worldChunk) -> {
            List<class_2338> botAttachedSlabPositions = worldChunk.getAttached(SlabChunkAttachment.BOT_SLAB_POSITIONS);
            if (botAttachedSlabPositions != null && !botAttachedSlabPositions.isEmpty()) {
                for (class_2338 pos : botAttachedSlabPositions) {
                    placeBottomSlab(worldChunk, pos);
                }
                worldChunk.setAttached(SlabChunkAttachment.BOT_SLAB_POSITIONS, new ArrayList<>());
            }
            List<class_2338> topAttachedSlabPositions = worldChunk.getAttached(SlabChunkAttachment.TOP_SLAB_POSITIONS);
            if (topAttachedSlabPositions != null && !topAttachedSlabPositions.isEmpty()) {
                for (class_2338 pos : topAttachedSlabPositions) {
                    placeTopSlab(worldChunk, pos);
                }
                worldChunk.setAttached(SlabChunkAttachment.TOP_SLAB_POSITIONS, new ArrayList<>());
            }
        });
    }

    private static void placeBottomSlab(class_2818 worldChunk, class_2338 placePos) {
        class_2338 blockBelowPos = placePos.method_10074();
        class_2338 blockAbovePos = placePos.method_10084();
        class_2680 blockAboveState = worldChunk.method_8320(blockAbovePos);
        class_2680 currentBlockState = worldChunk.method_8320(placePos);
        class_2680 blockBelowState = worldChunk.method_8320(blockBelowPos);

        if ( bottomSlabForbidden( currentBlockState ) ) {
            return;
        }
        // Retrieve the slab type based on the block below the current position
        class_2680 slabState = ModSlabsMap.getSlabForBlock(blockBelowState.method_26204()).method_9564();

        if (slabState.method_26204().equals(class_2246.field_10124)) {
            /* DEBUG
            System.out.println(blockBelowState);
            System.out.println(currentBlockState);
             */
            return;
        }

        // check if section is too high
        int sectionIndex = worldChunk.method_31602(blockAbovePos.method_10264());
        if (sectionIndex < 0 || sectionIndex >= worldChunk.method_12006().length) {
            return;
        }

        // remove double tall plants
        if (currentBlockState.method_26164(ModBlockTags.TALL_DECORATIONS) || currentBlockState.method_26164(class_3481.field_20338)) {
            if (currentBlockState.method_27852(class_2246.field_10238)) {
                setBlockWithoutUpdates(worldChunk, blockAbovePos, class_2246.field_10382.method_9564());
                blockAboveState = class_2246.field_10382.method_9564();
            }
            else {
                setBlockWithSection( worldChunk, blockAbovePos, class_2246.field_10124.method_9564() );
                blockAboveState = class_2246.field_10124.method_9564();
            }
        }
        // Handle grass slab special case by converting grass to dirt before placing the slab
        if (ModSlabsMap.BLOCK_BELOW_REPLACEMENT_MAP.containsKey(slabState.method_26204())) {
            setBlockWithSection( worldChunk, blockBelowPos, ModSlabsMap.BLOCK_BELOW_REPLACEMENT_MAP.get(slabState.method_26204()).method_9564() );
        }
        slabState = updateBottomWaterloggedState(currentBlockState, blockAboveState, slabState);

        // place vegetation / snow on top
        if (MyModConfig.enableVegetationOnSlabs) {
            placeVegetationOnTop(worldChunk, currentBlockState, blockAboveState, blockAbovePos);
        }
        if (currentBlockState.method_27852(class_2246.field_10477)) {
            if (MyModConfig.enableSnowOnSlabs) {
                class_2680 snowState = ModBlocksRegistry.SNOW_ON_TOP.method_9564();
                setBlockWithoutUpdates(worldChunk, blockAbovePos, snowState);
                if (slabState.method_28501().contains(class_2741.field_12512)) {
                    slabState = slabState.method_11657(class_2741.field_12512, true);
                }
            } else {
                slabState = ModBlocksRegistry.SNOW_SLAB.method_9564();
            }
        }
        setBlockWithoutUpdates(worldChunk, placePos,  slabState.method_11657(CustomSlab.GENERATED, true));
    }

    private static boolean bottomSlabForbidden( class_2680 currentBlockState ) {
        return !(currentBlockState.method_27852(class_2246.field_10124) || currentBlockState.method_27852(class_2246.field_10382) || currentBlockState.method_27852(class_2246.field_10543) || currentBlockState.method_27852(class_2246.field_10243)  || currentBlockState.method_27852(class_2246.field_10164))
                && !currentBlockState.method_26164(ModBlockTags.TALL_DECORATIONS) && !currentBlockState.method_26164(class_3481.field_20338)
                && !ModSlabsMap.ON_TOP_VEGETATION_BLOCKS_MAP.containsKey(currentBlockState.method_26204()) && !currentBlockState.method_27852(class_2246.field_10477)
                && !currentBlockState.method_26164(class_3481.field_44471) && !currentBlockState.method_26164(class_3481.field_44470);
    }

    static void setBlockWithoutUpdates(class_2818 chunk, class_2338 pos, class_2680 state) {
        int y = pos.method_10264();
        int lx = pos.method_10263() & 15;
        int lz = pos.method_10260() & 15;
        int ly = y & 15;

        class_2826 section = chunk.method_38259(chunk.method_31602(y));

        class_2680 previous = section.method_16675(lx, ly, lz, state);
        if (previous == state) {
            return;
        }
        for (class_2902.class_2903 type : class_2902.class_2903.values()) {
            class_2902 hm = chunk.method_12032(type);
            if (hm != null) {
                hm.method_12597(lx, y, lz, state);
            }
        }
        chunk.method_12008(true);
    }

    static void setBlockWithSection( class_2818 chunk, class_2338 pos, class_2680 state ) {
        int y = pos.method_10264();
        int lx = pos.method_10263() & 15;
        int lz = pos.method_10260() & 15;
        int ly = y & 15;

        class_2826 section = chunk.method_38259(chunk.method_31602(y));

        section.method_16675(lx, ly, lz, state);
    }

    private static void placeTopSlab(class_2818 worldChunk, class_2338 placePos) {
        class_2680 blockAboveState = worldChunk.method_8320(placePos.method_10084());

        // Retrieve the slab type based on the block below the current position
        class_2680 slabState = ModSlabsMap.getSlabForBlock(blockAboveState.method_26204()).method_9564();

        if (slabState.method_26204().equals(class_2246.field_10124)) {
            /* DEBUG
            System.out.println(blockBelowState);
            System.out.println(currentBlockState);
             */
            return;
        }
        if (ModSlabsMap.TOP_SLAB_REPLACEMENT_MAP.containsKey((slabState.method_26204()))) {
            slabState = ModSlabsMap.TOP_SLAB_REPLACEMENT_MAP.get(slabState.method_26204()).method_9564();
        }
        slabState = updateTopWaterloggedState(worldChunk, placePos, slabState);
        setBlockWithSection(worldChunk, placePos, slabState.method_11657(CustomSlab.GENERATED, true).method_11657(class_2741.field_12485, class_2771.field_12679));
    }

    private static void placeVegetationOnTop(class_2818 worldChunk, class_2680 currentBlockState, class_2680 blockAboveState, class_2338 blockAbovePos) {
        if ( !ModSlabsMap.ON_TOP_VEGETATION_BLOCKS_MAP.containsKey(currentBlockState.method_26204()) ) {
            return;
        }

        class_2680 vegetationState = ModSlabsMap.ON_TOP_VEGETATION_BLOCKS_MAP.get(currentBlockState.method_26204()).method_34725(currentBlockState);
        boolean canBeWaterlogged = vegetationState.method_28501().contains( class_2741.field_12508 );
        boolean blockAboveIsWater = blockAboveState.method_26204().equals(class_2246.field_10382 );
        if ( lacksValidFluidStateAndReplacement( vegetationState, canBeWaterlogged, blockAboveIsWater, blockAboveState.method_26215() )) {
            return;
        }

        if ( vegetationState.method_26204() instanceof class_2320 ) {
            class_2338 topPos = blockAbovePos.method_10084();
            class_2680 topState = worldChunk.method_8320( topPos );
            boolean topBlockIsWater = topState.method_26204().equals( class_2246.field_10382 );
            if ( lacksValidFluidStateAndReplacement( topState, canBeWaterlogged, topBlockIsWater, topState.method_26215()) ) {
                return;
            }

            class_2680 topVegeState = vegetationState.method_11657( class_2741.field_12533, class_2756.field_12609 );
            setBlockWithSection( worldChunk, topPos, withWaterloggedState( topVegeState, canBeWaterlogged, topBlockIsWater ) );
        }

        setBlockWithSection( worldChunk, blockAbovePos, withWaterloggedState( vegetationState, canBeWaterlogged, blockAboveIsWater ) );
    }

    // Checks is position is available and valid fluid state is possible
    private static boolean lacksValidFluidStateAndReplacement(class_2680 vegetationState, boolean canBeWaterlogged, boolean blockIsWater, boolean blockIsAir ) {
        return !( blockIsWater || blockIsAir )
                || blockIsWater && !( canBeWaterlogged || vegetationState.method_26164( ModBlockTags.REQUIRES_WATER ))
                || !blockIsWater && vegetationState.method_26164( ModBlockTags.REQUIRES_WATER );
    }
    private static class_2680 withWaterloggedState(class_2680 vegetationState, boolean canBeWaterlogged, boolean blockIsWater ) {
        return canBeWaterlogged ? vegetationState.method_11657( class_2741.field_12508, blockIsWater ) : vegetationState;
    }

    private static class_2680 updateBottomWaterloggedState(class_2680 currentBlockState, class_2680 blockAboveState, class_2680 slabState) {
        if (slabState.method_28498(class_2741.field_12508)) {
            if (currentBlockState.method_27852(class_2246.field_10382) || blockAboveState.method_27852(class_2246.field_10382)
                    || currentBlockState.method_26227() == class_3612.field_15910.method_15729(false) )
            {
                return slabState.method_11657(class_2741.field_12508, true);
            }
        }
        return slabState;
    }

    private static class_2680 updateTopWaterloggedState(class_2818 worldChunk, class_2338 currentPos, class_2680 slabState) {
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 checkPos = currentPos.method_10093(direction);
            class_1923 chunkPos = new class_1923(checkPos);

            // Check if the neighbor or the block above contains water to set the waterlogged property
            if (worldChunk.method_8320(currentPos.method_10093(direction)).method_27852(class_2246.field_10382) && worldChunk.method_12004().equals(chunkPos)) {
                return slabState.method_11657(class_2741.field_12508, true);
            }
        }
        return slabState;
    }
}
