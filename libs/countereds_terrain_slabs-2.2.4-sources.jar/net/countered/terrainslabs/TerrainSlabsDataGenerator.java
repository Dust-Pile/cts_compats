package net.countered.terrainslabs;

import net.countered.datagen.*;
import net.countered.terrainslabs.worldgen.feature.ModConfiguredFeatures;
import net.countered.terrainslabs.worldgen.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class TerrainSlabsDataGenerator implements DataGeneratorEntrypoint {
	@Override
	public void buildRegistry(class_7877 registryBuilder) {
		registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
		registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
	}

	@Override
	public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
		FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();
		pack.addProvider(ModWorldGenerator::new);
		pack.addProvider(ModModelProvider::new);
		pack.addProvider(ModLootTableProvider::new);
		pack.addProvider(ModBlockTagsProvider::new);
		pack.addProvider(ModRecipeProvider::new);
	}
}
