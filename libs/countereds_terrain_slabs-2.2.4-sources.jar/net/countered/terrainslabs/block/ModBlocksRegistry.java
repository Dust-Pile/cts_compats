package net.countered.terrainslabs.block;

import net.countered.terrainslabs.TerrainSlabs;
import net.countered.terrainslabs.block.customslabs.soilslabs.GrassSlab;
import net.countered.terrainslabs.block.customslabs.soilslabs.PathSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.GravityAffectedSlab;
import net.countered.terrainslabs.block.customslabs.soilslabs.MyceliumSlab;
import net.countered.terrainslabs.block.customslabs.soilslabs.PodzolSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.MudSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.dimensions.NetherrackSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.dimensions.NyliumSlab;
import net.countered.terrainslabs.block.customslabs.specialslabs.dimensions.SoulSandSlab;
import net.countered.terrainslabs.block.ontopofslabs.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6808;
import net.minecraft.class_7923;

public class ModBlocksRegistry {

    public static final class_2248 DIRT_SLAB = registerBlock("dirt_slab",
            new CustomSlab(class_2246.field_10566));
    public static final class_2248 MUD_SLAB = registerBlock("mud_slab",
            new MudSlab(class_2246.field_37576));
    public static final class_2248 COARSE_SLAB = registerBlock("coarse_slab",
            new CustomSlab(class_2246.field_10253));
    public static final class_2248 SNOW_SLAB = registerBlock("snow_slab",
            new CustomSlab(class_2246.field_10491));
    public static final class_2248 PACKED_ICE_SLAB = registerBlock("packed_ice_slab",
            new CustomSlab(class_2246.field_10225));
    public static final class_2248 DEEPSLATE_SLAB = registerBlock("deepslate_slab",
            new CustomSlab(class_2246.field_28888));
    public static final class_2248 CLAY_SLAB = registerBlock("clay_slab",
            new CustomSlab(class_2246.field_10460));
    public static final class_2248 MOSS_SLAB = registerBlock("moss_slab",
            new CustomSlab(class_2246.field_28681));
    public static final class_2248 CUSTOM_TUFF_SLAB = registerBlock("terrain_tuff_slab",
            new CustomSlab(class_2246.field_27165));

    public static final class_2248 GRASS_SLAB = registerBlock("grass_slab",
            new GrassSlab(class_2246.field_10219));
    public static final class_2248 MYCELIUM_SLAB = registerBlock("mycelium_slab",
            new MyceliumSlab(class_2246.field_10402));
    public static final class_2248 PODZOL_SLAB = registerBlock("podzol_slab",
            new PodzolSlab(class_2246.field_10520));
    public static final class_2248 PATH_SLAB = registerBlock("path_slab",
            new PathSlab(class_2246.field_10194));

    public static final class_2248 GRAVEL_SLAB = registerBlock("gravel_slab",
            new GravityAffectedSlab(class_2246.field_10255));
    public static final class_2248 SAND_SLAB = registerBlock("sand_slab",
            new GravityAffectedSlab(class_2246.field_10102));
    public static final class_2248 RED_SAND_SLAB = registerBlock("red_sand_slab",
            new GravityAffectedSlab(class_2246.field_10534));

    public static final class_2248 TERRACOTTA_SLAB = registerBlock("terracotta_slab",
            new CustomSlab(class_2246.field_10415));
    public static final class_2248 RED_TERRACOTTA_SLAB = registerBlock("red_terracotta_slab",
            new CustomSlab(class_2246.field_10328));
    public static final class_2248 ORANGE_TERRACOTTA_SLAB = registerBlock("orange_terracotta_slab",
            new CustomSlab(class_2246.field_10184));
    public static final class_2248 LIGHT_GRAY_TERRACOTTA_SLAB = registerBlock("light_gray_terracotta_slab",
            new CustomSlab(class_2246.field_10590));
    public static final class_2248 WHITE_TERRACOTTA_SLAB = registerBlock("white_terracotta_slab",
            new CustomSlab(class_2246.field_10611));
    public static final class_2248 BROWN_TERRACOTTA_SLAB = registerBlock("brown_terracotta_slab",
            new CustomSlab(class_2246.field_10123));
    public static final class_2248 YELLOW_TERRACOTTA_SLAB = registerBlock("yellow_terracotta_slab",
            new CustomSlab(class_2246.field_10143));

    public static final class_2248 CUSTOM_STONE_SLAB = registerBlock("terrain_stone_slab",
            new CustomSlab(class_2246.field_10454));
    public static final class_2248 CUSTOM_SANDSTONE_SLAB = registerBlock("terrain_sandstone_slab",
            new CustomSlab(class_2246.field_10007));
    public static final class_2248 CUSTOM_RED_SANDSTONE_SLAB = registerBlock("terrain_red_sandstone_slab",
            new CustomSlab(class_2246.field_10624));
    public static final class_2248 CUSTOM_ANDESITE_SLAB = registerBlock("terrain_andesite_slab",
            new CustomSlab(class_2246.field_10016));
    public static final class_2248 CUSTOM_DIORITE_SLAB = registerBlock("terrain_diorite_slab",
            new CustomSlab(class_2246.field_10507));
    public static final class_2248 CUSTOM_GRANITE_SLAB = registerBlock("terrain_granite_slab",
            new CustomSlab(class_2246.field_10189));

    public static final class_2248 SOUL_SAND_SLAB = registerBlock("soul_sand_slab",
            new SoulSandSlab(class_2246.field_10114));
    public static final class_2248 SOUL_SOIL_SLAB = registerBlock("soul_soil_slab",
            new CustomSlab(class_2246.field_22090));
    public static final class_2248 NETHERRACK_SLAB = registerBlock("netherrack_slab",
            new NetherrackSlab(class_2246.field_10515));
    public static final class_2248 WARPED_NYLIUM_SLAB = registerBlock("warped_nylium_slab",
            new NyliumSlab(class_2246.field_22113));
    public static final class_2248 CRIMSON_NYLIUM_SLAB = registerBlock("crimson_nylium_slab",
            new NyliumSlab(class_2246.field_22120));
    public static final class_2248 BASALT_SLAB = registerBlock("basalt_slab",
            new CustomSlab(class_2246.field_22091));
    public static final class_2248 CUSTOM_BLACKSTONE_SLAB = registerBlock("terrain_blackstone_slab",
            new CustomSlab(class_2246.field_23872));
    public static final class_2248 ENDSTONE_SLAB = registerBlock("endstone_slab",
            new CustomSlab(class_2246.field_10471));

    //terralith
    public static final class_2248 CALCITE_SLAB = registerBlock("calcite_slab",
            new CustomSlab(class_2246.field_27114));
    public static final class_2248 SMOOTH_BASALT_SLAB = registerBlock("smooth_basalt_slab",
            new CustomSlab(class_2246.field_29032));
    public static final class_2248 LIGHT_BLUE_TERRACOTTA_SLAB = registerBlock("light_blue_terracotta_slab",
            new CustomSlab(class_2246.field_10325));
    public static final class_2248 CYAN_TERRACOTTA_SLAB = registerBlock("cyan_terracotta_slab",
            new CustomSlab(class_2246.field_10235));
    public static final class_2248 CUSTOM_COBBLESTONE_SLAB = registerBlock("terrain_cobblestone_slab",
            new CustomSlab(class_2246.field_10351));
    public static final class_2248 CUSTOM_MOSSY_COBBLESTONE_SLAB = registerBlock("terrain_mossy_cobblestone_slab",
            new CustomSlab(class_2246.field_10405));
    public static final class_2248 CUSTOM_COBBLED_DEEPSLATE_SLAB = registerBlock("terrain_cobbled_deepslate_slab",
            new CustomSlab(class_2246.field_28890));
    public static final class_2248 ICE_SLAB = registerBlock("ice_slab",
            new CustomSlab(class_2246.field_10295));
    public static final class_2248 ROOTED_DIRT_SLAB = registerBlock("rooted_dirt_slab",
            new CustomSlab(class_2246.field_28685));
    public static final class_2248 PACKED_MUD_SLAB = registerBlock("packed_mud_slab",
            new CustomSlab(class_2246.field_37556));
    public static final class_2248 BLUE_ICE_SLAB = registerBlock("blue_ice_slab",
            new CustomSlab(class_2246.field_10384));
    public static final class_2248 BLACK_TERRACOTTA_SLAB = registerBlock("black_terracotta_slab",
            new CustomSlab(class_2246.field_10626));
    public static final class_2248 CUSTOM_PRISMARINE_SLAB = registerBlock("terrain_prismarine_slab",
            new CustomSlab(class_2246.field_10389));

    public static final class_2248 SNOW_ON_TOP = registerBlock("snow_on_top",
            new SnowOnTop(class_2246.field_10477));
    public static final class_2248 SEAGRASS_ON_TOP = registerBlock("seagrass_on_top",
            new SeagrassOnTop(class_2246.field_10376));
    public static final class_2248 POPPY_ON_TOP = registerBlock("poppy_on_top",
            new FlowerOnTop(class_2246.field_10449));
    public static final class_2248 DANDELION_ON_TOP = registerBlock("dandelion_on_top",
            new FlowerOnTop(class_2246.field_10182));
    public static final class_2248 AZURE_BLUET_ON_TOP = registerBlock("azure_bluet_on_top",
            new FlowerOnTop(class_2246.field_10573));
    public static final class_2248 CORNFLOWER_ON_TOP = registerBlock("cornflower_on_top",
            new FlowerOnTop(class_2246.field_9995));
    public static final class_2248 DEAD_BUSH_ON_TOP = registerBlock("dead_bush_on_top",
            new DeadBushOnTop(class_2246.field_10428));
    public static final class_2248 BROWN_MUSHROOM_ON_TOP = registerBlock("brown_mushroom_on_top",
            new MushroomOnTop(class_2246.field_10251, class_6808.field_35903));
    public static final class_2248 RED_MUSHROOM_ON_TOP = registerBlock("red_mushroom_on_top",
            new MushroomOnTop(class_2246.field_10559, class_6808.field_35904));
    public static final class_2248 SHORT_GRASS_ON_TOP = registerBlock("short_grass_on_top",
            new GrassOnTop(class_2246.field_10479));
    public static final class_2248 FERN_ON_TOP = registerBlock("fern_on_top",
            new GrassOnTop(class_2246.field_10112));



    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, new class_2960(TerrainSlabs.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(TerrainSlabs.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    public static void registerModBlocks() {
        TerrainSlabs.LOGGER.info("Registering Mod Blocks for " + TerrainSlabs.MOD_ID);
    }
}
