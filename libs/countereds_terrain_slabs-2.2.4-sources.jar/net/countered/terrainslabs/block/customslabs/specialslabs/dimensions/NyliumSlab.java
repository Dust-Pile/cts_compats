package net.countered.terrainslabs.block.customslabs.specialslabs.dimensions;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3558;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class NyliumSlab extends CustomSlab implements class_2256 {

    public NyliumSlab(class_2248 originalBlock ) {
        super( originalBlock );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }

    private static boolean stayAlive(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 blockPos = pos.method_10084();
        class_2680 blockState = world.method_8320(blockPos);
        int i = class_3558.method_20049(world, class_2246.field_22113.method_9564(), pos, blockState, blockPos, class_2350.field_11036, blockState.method_26193(world, blockPos));
        return i < 15;
    }

    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (!stayAlive(state, world, pos)) {
            if (state.method_11654(field_11501) == class_2771.field_12679) {
                world.method_8652(pos, ModBlocksRegistry.NETHERRACK_SLAB.method_9564().method_11657(field_11501, class_2771.field_12679), 3);
            }
            else if (state.method_11654(field_11501) == class_2771.field_12682) {
                world.method_8652(pos, ModBlocksRegistry.NETHERRACK_SLAB.method_9564().method_11657(field_11501, class_2771.field_12682), 3);
            }
            else if (state.method_11654(field_11501) == class_2771.field_12681){
                world.method_8652(pos, ModBlocksRegistry.NETHERRACK_SLAB.method_9564().method_11657(field_11501, class_2771.field_12681), 3);
            }
        }
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state, boolean isClient) {
        return false;
    }

    @Override
    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {

    }
}
