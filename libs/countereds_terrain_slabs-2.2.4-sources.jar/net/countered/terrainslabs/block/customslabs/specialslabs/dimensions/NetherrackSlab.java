package net.countered.terrainslabs.block.customslabs.specialslabs.dimensions;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class NetherrackSlab extends CustomSlab implements class_2256{

    public NetherrackSlab(class_2248 originalBlock ) {
        super( originalBlock );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state, boolean isClient) {
        if (!world.method_8320(pos.method_10084()).method_26167(world, pos)) {
            return false;
        } else {
            for (class_2338 blockPos : class_2338.method_10097(pos.method_10069(-1, -1, -1), pos.method_10069(1, 1, 1))) {
                if (world.method_8320(blockPos).method_26164(class_3481.field_21953)) {
                    return true;
                }
            }

            return false;
        }
    }

    @Override
    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
        boolean hasWarped = false;
        boolean hasCrimson = false;

        // Check neighboring blocks for nylium
        for (class_2338 blockPos : class_2338.method_10097(pos.method_10069(-1, -1, -1), pos.method_10069(1, 1, 1))) {
            class_2680 blockState = world.method_8320(blockPos);
            if (blockState.method_27852(class_2246.field_22113) || blockState.method_27852(ModBlocksRegistry.WARPED_NYLIUM_SLAB)) {
                hasWarped = true;
            }

            if (blockState.method_27852(class_2246.field_22120) || blockState.method_27852(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB)) {
                hasCrimson = true;
            }

            if (hasWarped && hasCrimson) {
                break; // No need to check further
            }
        }

        // Determine the new state based on neighboring nylium
        class_2680 newState = null;
        if (hasWarped && hasCrimson) {
            newState = random.method_43056() ? ModBlocksRegistry.WARPED_NYLIUM_SLAB.method_9564() : ModBlocksRegistry.CRIMSON_NYLIUM_SLAB.method_9564();
        } else if (hasWarped) {
            newState = ModBlocksRegistry.WARPED_NYLIUM_SLAB.method_9564();
        } else if (hasCrimson) {
            newState = ModBlocksRegistry.CRIMSON_NYLIUM_SLAB.method_9564();
        }

        // If a new state was determined, copy the slab type and update the block
        if (newState != null) {
            class_2771 slabType = state.method_11654(class_2482.field_11501); // Get current slab type
            newState = newState.method_11657(class_2482.field_11501, slabType); // Apply it to the new state
            world.method_8652(pos, newState, class_2248.field_31036);
        }
    }
}
