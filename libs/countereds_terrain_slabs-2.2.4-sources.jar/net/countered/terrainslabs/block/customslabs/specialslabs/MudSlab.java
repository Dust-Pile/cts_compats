package net.countered.terrainslabs.block.customslabs.specialslabs;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.minecraft.class_3726;
import net.minecraft.class_4970;

public class MudSlab extends CustomSlab {
    protected static final class_265 BOTTOM_SHAPE_COL = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 7.0, 16.0);
    protected static final class_265 FULL_SHAPE_COL = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 14.0, 16.0);
    protected static final class_265 TOP_SHAPE_COL = class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 14.0, 16.0);

    protected static final class_265 BOTTOM_SHAPE_OUT = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 8.0, 16.0);
    protected static final class_265 TOP_SHAPE_OUT = class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 16.0, 16.0);

    public MudSlab(class_2248 originalBlock ) {
        super( originalBlock, class_4970.class_2251.method_9630( originalBlock ).method_26245(class_2246::method_26122) );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return FULL_SHAPE_COL;
            case field_12679:
                return TOP_SHAPE_COL;
            default:
                return BOTTOM_SHAPE_COL;
        }
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return class_259.method_1077();
            case field_12679:
                return TOP_SHAPE_OUT;
            default:
                return BOTTOM_SHAPE_OUT;
        }
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return class_259.method_1077();
            case field_12679:
                return TOP_SHAPE_OUT;
            default:
                return BOTTOM_SHAPE_OUT;
        }
    }
    @Override
    public float method_9575(class_2680 state, class_1922 world, class_2338 pos) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return 0.2F;
            default:
                return 1F;
        }
    }
}

