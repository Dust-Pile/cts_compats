package net.countered.terrainslabs.block.customslabs.specialslabs;

import net.countered.terrainslabs.block.interfaces.BlockCopyWrapper;
import net.countered.terrainslabs.block.interfaces.IBlockCopy;
import net.minecraft.block.*;
import net.minecraft.class_1540;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_5688;
import net.minecraft.class_5819;
import net.minecraft.class_5945;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("deprecation")
public class GravityAffectedSlab extends CustomSlab implements class_5688 {

    public GravityAffectedSlab(class_2248 originalBlock ) {
        super( originalBlock );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, false)
                .method_11657(GENERATED, false));
    }

    @Override
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        world.method_39279(pos, this, this.getFallDelay());
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if ( canFallThrough( world.method_8320( pos.method_10074() ) ) && pos.method_10264() >= world.method_31607() ) {
            // FallingBlockEntity fallingBlockEntity =
            class_1540.method_40005( world, pos, state );
            // this.configureFallingBlockEntity(fallingBlockEntity);
        }
    }
    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        world.method_39279(pos, this, this.getFallDelay());
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    private boolean canFallThrough( class_2680 state ) {
        return class_2346.method_10128( state )
                || ( state.method_27852( this ) && state.method_11654( field_11501 ).equals( class_2771.field_12681 ) );
    }

//    protected void configureFallingBlockEntity(FallingBlockEntity entity) {
//    }

    /**
     * Gets the amount of time in ticks this block will wait before attempting to start falling.
     */
    protected int getFallDelay() {
        return 2;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(16) == 0) {
            class_2338 blockPos = pos.method_10074();
            if ( canFallThrough(world.method_8320(blockPos))) {
                class_5945.method_49099(world, pos, random, new class_2388(class_2398.field_11206, state));
            }
        }
    }

//    public int getColor(BlockState state, BlockView world, BlockPos pos) {
//        return -16777216;
//    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_2680 blockState = ctx.method_8045().method_8320(blockPos);
        if (blockState.method_27852(this)) {
            return blockState.method_11657(field_11501, class_2771.field_12682).method_11657(field_11502, false );
        } else {
            class_3610 fluidState = ctx.method_8045().method_8316(blockPos);
            class_2680 blockState2 = this.method_9564().method_11657(field_11501, class_2771.field_12681).method_11657(field_11502, fluidState.method_15772() == class_3612.field_15910);
            class_2350 direction = ctx.method_8038();
            return direction != class_2350.field_11033 && (direction == class_2350.field_11036 || !(ctx.method_17698().field_1351 - (double)blockPos.method_10264() > 0.5))
                    ? blockState2
                    : blockState2.method_11657(field_11501, class_2771.field_12681);
        }
    }

    @Override
    public void method_10129(class_1937 world, class_2338 pos, class_1540 fallingBlockEntity) {
        class_2680 fallingBlockState = fallingBlockEntity.method_6962();
        class_2680 landedOnBlockState = world.method_8320( pos );

        //No need to check state, would only trigger on bottom slab
        if ( landedOnBlockState.method_27852( this ) ) {
            class_2248 originBlock = new BlockCopyWrapper( (IBlockCopy) fallingBlockState.method_26204() ).getOriginBlock();

            if ( fallingBlockState.method_11654( field_11501 ).equals( class_2771.field_12682 ) ) {
                class_2680 aboveState = world.method_8320( pos.method_10084() );
                if ( !( aboveState.method_26164( class_3481.field_44471 ) || aboveState.method_26215() || aboveState.method_27852( class_2246.field_10382 ) ) ) {
                    method_9577(world, pos, new class_1799(this.getOriginItem()));
                    return;
                }

                world.method_8501( pos.method_10084(), this.method_34725( landedOnBlockState )
                        .method_11657( field_11501, class_2771.field_12681 ) );

                if ( landedOnBlockState.method_11654( GENERATED ) ) {
                    originBlock.method_34725( landedOnBlockState );
                } else {
                    world.method_8501( pos, this.method_9564().method_11657( field_11501, class_2771.field_12682 ));
                }
            } else {
                if ( landedOnBlockState.method_11654( GENERATED ) ) {
                    world.method_8501( pos, originBlock.method_34725( landedOnBlockState ) );
                } else {
                    world.method_8501( pos, this.method_9564().method_11657( field_11501, class_2771.field_12682 ));
                }
            }
            return;
        }

        // Loot if checks fail
        if ( fallingBlockState.method_11654(field_11501).equals( class_2771.field_12682) ) {
            method_9577(world, pos, new class_1799(this.getOriginItem(), 2));
        } else {
            method_9577(world, pos, new class_1799(this.getOriginItem()));
        }
    }

    @Override
    public void method_10127(class_1937 world, class_2338 pos, class_2680 fallingBlockState, class_2680 currentStateInPos, class_1540 fallingBlockEntity) {
        if ( fallingBlockState.method_11654( field_11501 ) == class_2771.field_12679 ) {
            world.method_8501( pos, fallingBlockState.method_11657( field_11501, class_2771.field_12681 ) );
        }
    }
}

