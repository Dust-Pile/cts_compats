package net.countered.terrainslabs.block.customslabs.specialslabs;

import net.minecraft.class_1540;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_5688;
import net.minecraft.class_5819;
import net.minecraft.class_5945;
import org.jetbrains.annotations.Nullable;

public class GravityAffectedSlab extends CustomSlab implements class_5688 {

    public GravityAffectedSlab(class_2248 originalBlock ) {
        super( originalBlock );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        world.method_39279(pos, this, this.getFallDelay());
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (canFallThrough(world.method_8320(pos.method_10074())) && pos.method_10264() >= world.method_31607()) {
            class_1540 fallingBlockEntity = class_1540.method_40005(world, pos, state);
            this.configureFallingBlockEntity(fallingBlockEntity);
        }
    }
    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        world.method_39279(pos, this, this.getFallDelay());
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    protected void configureFallingBlockEntity(class_1540 entity) {
    }

    /**
     * Gets the amount of time in ticks this block will wait before attempting to start falling.
     */
    protected int getFallDelay() {
        return 2;
    }

    public static boolean canFallThrough(class_2680 state) {
        return state.method_26215() || state.method_26164(class_3481.field_21952) || state.method_51176() || state.method_45474();
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(16) == 0) {
            class_2338 blockPos = pos.method_10074();
            if (canFallThrough(world.method_8320(blockPos))) {
                class_5945.method_49099(world, pos, random, new class_2388(class_2398.field_11206, state));
            }
        }
    }

    public int getColor(class_2680 state, class_1922 world, class_2338 pos) {
        return -16777216;
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_2680 blockState = ctx.method_8045().method_8320(blockPos);
        if (blockState.method_27852(this)) {
            return blockState.method_11657(field_11501, class_2771.field_12682).method_11657(field_11502, Boolean.valueOf(false));
        } else {
            class_3610 fluidState = ctx.method_8045().method_8316(blockPos);
            class_2680 blockState2 = this.method_9564().method_11657(field_11501, class_2771.field_12681).method_11657(field_11502, Boolean.valueOf(fluidState.method_15772() == class_3612.field_15910));
            class_2350 direction = ctx.method_8038();
            return direction != class_2350.field_11033 && (direction == class_2350.field_11036 || !(ctx.method_17698().field_1351 - (double)blockPos.method_10264() > 0.5))
                    ? blockState2
                    : blockState2.method_11657(field_11501, class_2771.field_12681);
        }
    }

    @Override
    public void method_10129(class_1937 world, class_2338 pos, class_1540 fallingBlockEntity) {
        class_5688.super.method_10129(world, pos, fallingBlockEntity);
        if (fallingBlockEntity.method_6962().method_11654(field_11501) == class_2771.field_12682) {
            method_9577(world, pos, new class_1799(this.method_8389()));
        }
    }
    @Override
    public void method_10127(class_1937 world, class_2338 pos, class_2680 fallingBlockState, class_2680 currentStateInPos, class_1540 fallingBlockEntity) {
        class_5688.super.method_10127(world, pos, fallingBlockState, currentStateInPos, fallingBlockEntity);
        if (fallingBlockState.method_11654(field_11501) == class_2771.field_12679) {
            world.method_8501(pos, this.method_9564().method_11657(class_2741.field_12485, class_2771.field_12681));
        }
    }
}

