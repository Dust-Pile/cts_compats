package net.countered.terrainslabs.block.customslabs.specialslabs;

import net.countered.terrainslabs.block.interfaces.IBlockCopyFabric;
import net.minecraft.block.*;
import net.minecraft.class_2248;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2771;
import net.minecraft.class_4970;

public class CustomSlab extends class_2482 implements IBlockCopyFabric {
    public static final class_2746 GENERATED;
    private final class_2248 originalBlock;

    static {
        GENERATED = class_2746.method_11825("generated");
    }

    public CustomSlab( class_2248 originalBlock ) {
        this( originalBlock, class_4970.class_2251.method_9630( originalBlock ) );
    }
    protected CustomSlab( class_2248 originalBlock, class_2251 customSettings ) {
        super( customSettings );
        this.originalBlock = originalBlock;
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }

    @Override
    public class_2248 getOriginBlock() {
        return this.originalBlock;
    }

    @Override
    public BlockCopyType getCopyType() {
        return BlockCopyType.SLAB;
    }
}
