package net.countered.terrainslabs.block.customslabs.soilslabs;

import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2771;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_3612;

public class PodzolSlab extends CustomSlab {

    public PodzolSlab(class_2248 originalBlock ) {
        super( originalBlock );
        this.method_9590(this.field_10647.method_11664()
                .method_11657(class_2482.field_11501, class_2771.field_12681)
                .method_11657(SNOWY, false)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }
    public static final class_2746 SNOWY = class_2741.field_12512;

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (direction == class_2350.field_11036) {
            state = state.method_11657(SNOWY, isSnow(neighborState));
        }

        // Handle waterlogging logic
        if (state.method_11654(field_11502)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        // Return the modified state based on the slab's existing logic
        return state;
    }


    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_2680 currentState = ctx.method_8045().method_8320(blockPos);

        // Check if the block at the position is already a slab (and it's not a double slab yet)
        if (currentState.method_27852(this) && currentState.method_11654(field_11501) != class_2771.field_12682) {
            // Convert to a double slab if a slab is placed on an existing slab
            return currentState.method_11657(field_11501, class_2771.field_12682).method_11657(field_11502, false);
        }

        // Determine the snowy state based on the block above
        class_2680 blockAbove = ctx.method_8045().method_8320(blockPos.method_10084());
        class_2680 defaultState = this.method_9564().method_11657(SNOWY, isSnow(blockAbove));

        // Handle slab type and waterlogging for single slab placement
        class_3610 fluidState = ctx.method_8045().method_8316(blockPos);
        class_2680 slabState = defaultState.method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, fluidState.method_15772() == class_3612.field_15910);

        class_2350 direction = ctx.method_8038();

        // Adjust the slab type based on the placement context (whether it's a top or bottom slab)
        if (direction != class_2350.field_11033 && (direction == class_2350.field_11036 || !(ctx.method_17698().field_1351 - (double) blockPos.method_10264() > 0.5))) {
            return slabState;
        } else {
            return slabState.method_11657(field_11501, class_2771.field_12679);
        }
    }

    private static boolean isSnow(class_2680 state) {
        return state.method_26164(class_3481.field_29823);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(SNOWY, field_11501, field_11502, GENERATED);
    }
}
