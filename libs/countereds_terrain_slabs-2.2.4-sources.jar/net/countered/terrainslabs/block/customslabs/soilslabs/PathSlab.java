package net.countered.terrainslabs.block.customslabs.soilslabs;

import net.countered.terrainslabs.block.ModBlocksRegistry;
import net.countered.terrainslabs.block.customslabs.specialslabs.CustomSlab;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class PathSlab extends CustomSlab {

    public PathSlab(class_2248 originalBlock ) {
        super( originalBlock, class_4970.class_2251.method_9630( originalBlock ).method_26245(class_2246::method_26122) );
        this.method_9590(this.method_9564()
                .method_11657(field_11501, class_2771.field_12681)
                .method_11657(field_11502, Boolean.valueOf(false))
                .method_11657(GENERATED, Boolean.valueOf(false)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11501, field_11502, GENERATED);
    }


    @Override
    public boolean method_9526(class_2680 state) {
        return true;
    }

    protected static final class_265 BOTTOM_SHAPE_COL = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 7.0, 16.0);
    protected static final class_265 TOP_SHAPE_COL = class_2248.method_9541(0.0, 8.0, 0.0, 16.0, 15.0, 16.0);
    protected static final class_265 DOUBLE_SHAPE_COL = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 15.0, 16.0);

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return DOUBLE_SHAPE_COL;
            case field_12679:
                return TOP_SHAPE_COL;
            default:
                return BOTTOM_SHAPE_COL;
        }
    }
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                return DOUBLE_SHAPE_COL;
            case field_12679:
                return TOP_SHAPE_COL;
            default:
                return BOTTOM_SHAPE_COL;
        }
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2771 slabType = state.method_11654(field_11501);
        switch (slabType) {
            case field_12682:
                world.method_8501(pos, ModBlocksRegistry.DIRT_SLAB.method_9564().method_11657(field_11501, class_2771.field_12682));
                break;
            case field_12679:
                world.method_8501(pos, ModBlocksRegistry.DIRT_SLAB.method_9564().method_11657(field_11501, class_2771.field_12679));
                break;
            default:
                world.method_8501(pos, ModBlocksRegistry.DIRT_SLAB.method_9564().method_11657(field_11501, class_2771.field_12681));
                break;
        }
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2680 blockState = world.method_8320(pos.method_10084());
        return !blockState.method_51367() || blockState.method_26204() instanceof class_2349;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_2680 blockState = ctx.method_8045().method_8320(blockPos);

        // Check if the block at the position is the same as this slab type
        if (blockState.method_27852(this)) {
            return blockState.method_11657(field_11501, class_2771.field_12682).method_11657(field_11502, Boolean.FALSE);
        } else {
            class_3610 fluidState = ctx.method_8045().method_8316(blockPos);
            class_2680 blockState2 = this.method_9564().method_11657(field_11501, class_2771.field_12681)
                    .method_11657(field_11502, fluidState.method_15772() == class_3612.field_15910);

            class_2350 direction = ctx.method_8038();
            // Determine whether to place it as a bottom or top slab based on hit position
            if (direction != class_2350.field_11033 && (direction == class_2350.field_11036 || !(ctx.method_17698().field_1351 - (double)blockPos.method_10264() > 0.5))) {
                return blockState2;
            } else {
                // Ensure the placement is valid; otherwise, push entities up
                return !blockState2.method_26184(ctx.method_8045(), blockPos)
                        ? class_2248.method_9582(this.method_9564(), class_2246.field_10566.method_9564(), ctx.method_8045(), blockPos)
                        : blockState2.method_11657(field_11501, class_2771.field_12679);
            }
        }
    }


    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (direction == class_2350.field_11036 && !state.method_26184(world, pos)) {
            world.method_39279(pos, this, 1);
        }
        if ((Boolean)state.method_11654(field_11502)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }
        return state;
    }
}

