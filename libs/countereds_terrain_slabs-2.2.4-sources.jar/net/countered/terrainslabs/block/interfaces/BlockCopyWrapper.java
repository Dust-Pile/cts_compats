package net.countered.terrainslabs.block.interfaces;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public record BlockCopyWrapper(IBlockCopy blockCopy) implements IBlockCopyFabric {
    @Override
    public class_2248 getOriginBlock() {
        if (blockCopy instanceof IBlockCopyFabric blockCopyFabric) {
            return blockCopyFabric.getOriginBlock();
        }

        String[] identifierParts = blockCopy.getOriginBlockStrings();
        return class_7923.field_41175.method_10223(class_2960.method_43902(identifierParts[0], identifierParts[1]));
    }

    @Override
    public BlockCopyType getCopyType() {
        return blockCopy.getCopyType();
    }
}
