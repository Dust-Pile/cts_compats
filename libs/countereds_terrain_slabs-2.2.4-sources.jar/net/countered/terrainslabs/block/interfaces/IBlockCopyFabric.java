package net.countered.terrainslabs.block.interfaces;

import net.minecraft.class_1792;
import net.minecraft.class_2248;

public interface IBlockCopyFabric extends IBlockCopy {

    default String[] getOriginBlockStrings() {
        String[] strings = getOriginBlock().method_9539().split("\\.");
        return new String[] { strings[1], strings[2] };
    }

    class_2248 getOriginBlock();

    default class_1792 getOriginItem() {
        return getOriginBlock().method_8389();
    }
}
