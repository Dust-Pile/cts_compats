package net.countered.terrainslabs.block.ontopofslabs;


import net.countered.terrainslabs.block.interfaces.IBlockCopyFabric;
import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2476;
import net.minecraft.class_2482;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4970;


public class SeagrassOnTop extends class_2476 implements class_2256, class_2402, IBlockCopyFabric {
    protected static final class_265 SHAPE = class_2248.method_9541(2.0, -8.0, 2.0, 14.0, 4.0, 14.0);
    private final class_2248 originalBlock;

    public SeagrassOnTop(class_2248 originalBlock ) {
        super( class_4970.class_2251.method_9630( originalBlock ) );
        this.originalBlock = originalBlock;
    }
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return field_11485;
    }
    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_26204() instanceof class_2482;
    }

    @Override
    public class_2248 getOriginBlock() {
        return originalBlock;
    }

    @Override
    public BlockCopyType getCopyType() {
        return BlockCopyType.ON_TOP;
    }
}
