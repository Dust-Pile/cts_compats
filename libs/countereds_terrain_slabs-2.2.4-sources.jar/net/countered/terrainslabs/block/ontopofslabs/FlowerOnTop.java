package net.countered.terrainslabs.block.ontopofslabs;

import net.countered.terrainslabs.block.interfaces.IBlockCopyFabric;
import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2356;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4970;


public class FlowerOnTop extends class_2356 implements IBlockCopyFabric {
    private final class_2248 originalBlock;
    protected static final class_265 SHAPE = class_2248.method_9541(5.0, -8.0, 5.0, 11.0, 2.0, 11.0);

    public FlowerOnTop(class_2248 originalBlock ) {
        super( ((class_2356) originalBlock).method_10188(),
                ((class_2356) originalBlock).method_10187(),
                class_4970.class_2251.method_9630( originalBlock ));
        this.originalBlock = originalBlock;
    }


    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_243 vec3d = state.method_26226(world, pos);
        return field_11085.method_1096(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350);
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_26204() instanceof class_2482;
    }

    @Override
    public class_2248 getOriginBlock() {
        return originalBlock;
    }

    @Override
    public BlockCopyType getCopyType() {
        return BlockCopyType.ON_TOP;
    }
}
