package net.countered.terrainslabs.block.ontopofslabs;

import net.countered.terrainslabs.block.interfaces.IBlockCopyFabric;
import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2420;
import net.minecraft.class_2482;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5321;

public class MushroomOnTop extends class_2420 implements IBlockCopyFabric {
    private final class_2248 originalBlock;
    protected static final class_265 SHAPE = class_2248.method_9541(5.0, -8.0, 5.0, 11.0, -2.0, 11.0);

    public MushroomOnTop(class_2248 originalBlock, class_5321<class_2975<?, ?>> featureKey) {
        super( class_4970.class_2251.method_9630( originalBlock ), featureKey );
        this.originalBlock = originalBlock;
    }


    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return field_11304;
    }
    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_26204() instanceof class_2482;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 blockPos = pos.method_10074();
        class_2680 blockState = world.method_8320(blockPos);
        return this.method_9695(blockState, world, blockPos);
    }

    @Override
    public class_2248 getOriginBlock() {
        return originalBlock;
    }

    @Override
    public BlockCopyType getCopyType() {
        return BlockCopyType.ON_TOP;
    }
}
