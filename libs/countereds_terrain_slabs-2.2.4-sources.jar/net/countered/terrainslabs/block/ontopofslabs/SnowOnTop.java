package net.countered.terrainslabs.block.ontopofslabs;

import net.countered.terrainslabs.block.interfaces.IBlockCopyFabric;
import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;

import static net.minecraft.class_2482.field_11501;

public class SnowOnTop extends class_2488 implements IBlockCopyFabric {
    private final class_2248 originalBlock;

    public SnowOnTop(class_2248 originalBlock ) {
        super( class_4970.class_2251.method_9630( originalBlock ) );
        this.originalBlock = originalBlock;
    }

    protected static final class_265[] field_11517 = new class_265[]{
            class_259.method_1073(),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, -6.0,  16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, -4.0,  16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, -2.0,  16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, 0.0,  16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, 2.0, 16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, 4.0, 16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, 6.0, 16.0),
            class_2248.method_9541(0.0, -8.0, 0.0, 16.0, 8.0, 16.0)
    };
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return field_11517[state.method_11654(field_11518)];
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return field_11517[state.method_11654(field_11518)-1];
    }

    @Override
    public class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
        return field_11517[state.method_11654(field_11518)];
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return field_11517[state.method_11654(field_11518)];
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2680 blockState = world.method_8320(pos.method_10074());
        return blockState.method_26204() instanceof class_2482 && blockState.method_11654(field_11501).equals(class_2771.field_12681);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 world, class_2338 pos) {
        return 1.0F;
    }

    @Override
    public class_2248 getOriginBlock() {
        return originalBlock;
    }

    @Override
    public BlockCopyType getCopyType() {
        return BlockCopyType.ON_TOP;
    }
}
