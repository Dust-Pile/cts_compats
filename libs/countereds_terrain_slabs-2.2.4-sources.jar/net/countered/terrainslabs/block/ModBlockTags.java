package net.countered.terrainslabs.block;

import static net.countered.terrainslabs.TerrainSlabs.MOD_ID;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModBlockTags {
    public static final class_6862<class_2248> TALL_DECORATIONS =
            class_6862.method_40092(class_7924.field_41254, new class_2960(MOD_ID, "tall_decorations"));

    public static final class_6862<class_2248> SOIL_SLAB_BLOCKS =
            class_6862.method_40092(class_7924.field_41254, new class_2960(MOD_ID, "soil_slabs"));

    public static final class_6862<class_2248> REQUIRES_WATER =
            class_6862.method_40092(class_7924.field_41254, new class_2960(MOD_ID, "requires_water"));
}
