package net.countered.terrainslabs.block;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@SuppressWarnings("unused")
public class ModSlabsMap {
    public static final Map<class_2248, class_2248> SLAB_MAP = new HashMap<>();

    static {
        // Register your block-to-slab mappings here
        SLAB_MAP.put(class_2246.field_10340, ModBlocksRegistry.CUSTOM_STONE_SLAB);
        SLAB_MAP.put(class_2246.field_27165, ModBlocksRegistry.CUSTOM_TUFF_SLAB);
        SLAB_MAP.put(class_2246.field_9979, ModBlocksRegistry.CUSTOM_SANDSTONE_SLAB);
        SLAB_MAP.put(class_2246.field_10344, ModBlocksRegistry.CUSTOM_RED_SANDSTONE_SLAB);
        SLAB_MAP.put(class_2246.field_10115, ModBlocksRegistry.CUSTOM_ANDESITE_SLAB);
        SLAB_MAP.put(class_2246.field_10508, ModBlocksRegistry.CUSTOM_DIORITE_SLAB);
        SLAB_MAP.put(class_2246.field_10474, ModBlocksRegistry.CUSTOM_GRANITE_SLAB);

        SLAB_MAP.put(class_2246.field_10219, ModBlocksRegistry.GRASS_SLAB);
        SLAB_MAP.put(class_2246.field_10402, ModBlocksRegistry.MYCELIUM_SLAB);
        SLAB_MAP.put(class_2246.field_10520, ModBlocksRegistry.PODZOL_SLAB);
        SLAB_MAP.put(class_2246.field_10194, ModBlocksRegistry.PATH_SLAB);

        SLAB_MAP.put(class_2246.field_10255, ModBlocksRegistry.GRAVEL_SLAB);
        SLAB_MAP.put(class_2246.field_10102, ModBlocksRegistry.SAND_SLAB);
        SLAB_MAP.put(class_2246.field_10534, ModBlocksRegistry.RED_SAND_SLAB);

        SLAB_MAP.put(class_2246.field_10566, ModBlocksRegistry.DIRT_SLAB);
        SLAB_MAP.put(class_2246.field_37576, ModBlocksRegistry.MUD_SLAB);
        SLAB_MAP.put(class_2246.field_10253, ModBlocksRegistry.COARSE_SLAB);
        SLAB_MAP.put(class_2246.field_10491, ModBlocksRegistry.SNOW_SLAB);
        SLAB_MAP.put(class_2246.field_10225, ModBlocksRegistry.PACKED_ICE_SLAB);
        SLAB_MAP.put(class_2246.field_10460, ModBlocksRegistry.CLAY_SLAB);
        SLAB_MAP.put(class_2246.field_28888, ModBlocksRegistry.DEEPSLATE_SLAB);
        SLAB_MAP.put(class_2246.field_28681, ModBlocksRegistry.MOSS_SLAB);
        //terralith
        SLAB_MAP.put(class_2246.field_27114, ModBlocksRegistry.CALCITE_SLAB);
        SLAB_MAP.put(class_2246.field_29032, ModBlocksRegistry.SMOOTH_BASALT_SLAB);
        SLAB_MAP.put(class_2246.field_10325, ModBlocksRegistry.LIGHT_BLUE_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10235, ModBlocksRegistry.CYAN_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10445, ModBlocksRegistry.CUSTOM_COBBLESTONE_SLAB);
        SLAB_MAP.put(class_2246.field_9989, ModBlocksRegistry.CUSTOM_MOSSY_COBBLESTONE_SLAB);
        SLAB_MAP.put(class_2246.field_29031, ModBlocksRegistry.CUSTOM_COBBLED_DEEPSLATE_SLAB);
        SLAB_MAP.put(class_2246.field_10295, ModBlocksRegistry.ICE_SLAB);
        SLAB_MAP.put(class_2246.field_28685, ModBlocksRegistry.ROOTED_DIRT_SLAB);
        SLAB_MAP.put(class_2246.field_37556, ModBlocksRegistry.PACKED_MUD_SLAB);
        SLAB_MAP.put(class_2246.field_10384, ModBlocksRegistry.BLUE_ICE_SLAB);
        SLAB_MAP.put(class_2246.field_10626, ModBlocksRegistry.BLACK_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10135, ModBlocksRegistry.CUSTOM_PRISMARINE_SLAB);

        SLAB_MAP.put(class_2246.field_10415, ModBlocksRegistry.TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10328, ModBlocksRegistry.RED_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10184, ModBlocksRegistry.ORANGE_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10590, ModBlocksRegistry.LIGHT_GRAY_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10611, ModBlocksRegistry.WHITE_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10123, ModBlocksRegistry.BROWN_TERRACOTTA_SLAB);
        SLAB_MAP.put(class_2246.field_10143, ModBlocksRegistry.YELLOW_TERRACOTTA_SLAB);

        SLAB_MAP.put(class_2246.field_10114, ModBlocksRegistry.SOUL_SAND_SLAB);
        SLAB_MAP.put(class_2246.field_22090, ModBlocksRegistry.SOUL_SOIL_SLAB);
        SLAB_MAP.put(class_2246.field_10515, ModBlocksRegistry.NETHERRACK_SLAB);
        SLAB_MAP.put(class_2246.field_22113, ModBlocksRegistry.WARPED_NYLIUM_SLAB);
        SLAB_MAP.put(class_2246.field_22120, ModBlocksRegistry.CRIMSON_NYLIUM_SLAB);
        SLAB_MAP.put(class_2246.field_22091, ModBlocksRegistry.BASALT_SLAB);
        SLAB_MAP.put(class_2246.field_23869, ModBlocksRegistry.CUSTOM_BLACKSTONE_SLAB);
        SLAB_MAP.put(class_2246.field_10471, ModBlocksRegistry.ENDSTONE_SLAB);
    }
    public static final Map<class_2248, class_2248> ON_TOP_VEGETATION_BLOCKS_MAP = new HashMap<>();

    static {
        // Register your block-to-slab mappings here
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10449, ModBlocksRegistry.POPPY_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10182, ModBlocksRegistry.DANDELION_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10573, ModBlocksRegistry.AZURE_BLUET_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_9995, ModBlocksRegistry.CORNFLOWER_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10428, ModBlocksRegistry.DEAD_BUSH_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10251, ModBlocksRegistry.BROWN_MUSHROOM_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10559, ModBlocksRegistry.RED_MUSHROOM_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10479, ModBlocksRegistry.SHORT_GRASS_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10112, ModBlocksRegistry.FERN_ON_TOP);
        ON_TOP_VEGETATION_BLOCKS_MAP.put(class_2246.field_10376, ModBlocksRegistry.SEAGRASS_ON_TOP);
    }
    public static final Map<class_2248, class_2248> BLOCK_BELOW_REPLACEMENT_MAP = new HashMap<>();

    static {
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.GRASS_SLAB, class_2246.field_10566);
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.PODZOL_SLAB, class_2246.field_10566);
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.MYCELIUM_SLAB, class_2246.field_10566);
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.PATH_SLAB, class_2246.field_10566);
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.WARPED_NYLIUM_SLAB, class_2246.field_10515);
        BLOCK_BELOW_REPLACEMENT_MAP.put(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB, class_2246.field_10515);
    }
    public static final Map<class_2248, class_2248> TOP_SLAB_REPLACEMENT_MAP = new HashMap<>();

    static {
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.GRASS_SLAB, ModBlocksRegistry.DIRT_SLAB);
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.PODZOL_SLAB, ModBlocksRegistry.DIRT_SLAB);
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.MYCELIUM_SLAB, ModBlocksRegistry.DIRT_SLAB);
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.PATH_SLAB, ModBlocksRegistry.DIRT_SLAB);
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.WARPED_NYLIUM_SLAB, ModBlocksRegistry.NETHERRACK_SLAB);
        TOP_SLAB_REPLACEMENT_MAP.put(ModBlocksRegistry.CRIMSON_NYLIUM_SLAB, ModBlocksRegistry.NETHERRACK_SLAB);
    }

    public static class_2248 getSlabForBlock(class_2248 blockBelow) {
        return SLAB_MAP.getOrDefault(blockBelow, class_2246.field_10124); // Default slab if no match
    }

    // Utilities to allow forge compats to cross the platform barrier with a common java object
    public static void putOnTopVegetationFromString( String keyMod, String keyName, String valueMod, String valueName ) {
        putWithId( ON_TOP_VEGETATION_BLOCKS_MAP, keyMod, keyName, valueMod, valueName );
    }
    public static void putTerrainSlabFromString( String keyMod, String keyName, String valueMod, String valueName ) {
        putWithId( SLAB_MAP, keyMod, keyName, valueMod, valueName );
    }
    public static void putBlockBelowReplacementFromString( String keyMod, String keyName, String valueMod, String valueName ) {
        putWithId( BLOCK_BELOW_REPLACEMENT_MAP, keyMod, keyName, valueMod, valueName );
    }
    public static void putTopSlabReplacementFromString( String keyMod, String keyName, String valueMod, String valueName ) {
        putWithId( TOP_SLAB_REPLACEMENT_MAP, keyMod, keyName, valueMod, valueName );
    }

    private static void putWithId( Map<class_2248, class_2248> map, String keyMod, String keyName, String valueMod, String valueName ) {
        class_2248 block1 = class_7923.field_41175.method_10223( class_2960.method_43902( keyMod, keyName ) );
        class_2248 block2 = class_7923.field_41175.method_10223( class_2960.method_43902( valueMod, valueName ) );
        map.put( block1, block2 );
    }

}
