package net.countered.terrainslabs.persistence;

import com.mojang.serialization.Codec;
import net.countered.terrainslabs.TerrainSlabs;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import java.util.List;

public class SlabChunkAttachment {

    public static final AttachmentType<List<class_2338>> BOT_SLAB_POSITIONS = AttachmentRegistry.createPersistent(
            class_2960.method_43902(TerrainSlabs.MOD_ID, "bot_slab_positions"),
            Codec.list(class_2338.field_25064)
    );

    public static final AttachmentType<List<class_2338>> TOP_SLAB_POSITIONS = AttachmentRegistry.createPersistent(
            class_2960.method_43902(TerrainSlabs.MOD_ID, "top_slab_positions"),
            Codec.list(class_2338.field_25064)
    );

    public static void registerSlabAttachment() {;
    }
}