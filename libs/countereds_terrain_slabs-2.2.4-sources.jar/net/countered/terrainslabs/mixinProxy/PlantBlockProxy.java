package net.countered.terrainslabs.mixinProxy;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface PlantBlockProxy {

    boolean terrain_slabs_mod$canPlantOnTopProxy(class_2680 state, class_1922 world, class_2338 pos );

}
